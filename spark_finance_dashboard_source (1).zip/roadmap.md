# Roadmap

- [x] Report annual marine revenue ex-GST in the overview KPI.
- [x] Update annual income chart and net assessable turnover.
- [x] Separate ex-GST revenue, GST collected, and gross invoiced in marine and invoice views.
- [x] Keep Spark Advisor's financial context aligned with the revised GST treatment.