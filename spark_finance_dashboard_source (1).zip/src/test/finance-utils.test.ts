import { describe, expect, it } from "vitest";
import {
  calculatePortfolioKPIs,
  generateProjections,
  calculateThaiTax,
  type PortfolioHolding,
  type ProjectionParams,
  type ThaiTaxInput,
} from "@/lib/finance-utils";

describe("finance-utils", () => {
  it("calculates portfolio KPIs accurately", () => {
    const holdings: PortfolioHolding[] = [
      {
        ticker: "SPYI",
        name: "NEOS S&P 500 High Income ETF",
        shares: 100,
        avgCost: 50,
        currentPrice: 55,
        annualDividendYield: 0.12,
        category: "Option Income",
      },
      {
        ticker: "QQQI",
        name: "NEOS Nasdaq 100 High Income ETF",
        shares: 100,
        avgCost: 50,
        currentPrice: 50,
        annualDividendYield: 0.14,
        category: "Option Income",
      },
    ];

    const kpis = calculatePortfolioKPIs(holdings);

    expect(kpis.totalCost).toBe(10000);
    expect(kpis.totalValue).toBe(10500);
    expect(kpis.totalGainLoss).toBe(500);
    expect(kpis.totalGainLossPct).toBeCloseTo(5.0);
    expect(kpis.projectedAnnualIncome).toBe(100 * 55 * 0.12 + 100 * 50 * 0.14); // 660 + 700 = 1360
    expect(kpis.projectedMonthlyIncome).toBeCloseTo(1360 / 12);
  });

  it("generates compounding / DRIP projections", () => {
    const params: ProjectionParams = {
      initialValue: 10000,
      monthlyContribution: 500,
      annualYield: 0.10,
      annualGrowthRate: 0.05,
      years: 3,
      reinvestDividends: true,
    };

    const projections = generateProjections(params);

    expect(projections.length).toBe(3);
    expect(projections[0].year).toBe(1);
    expect(projections[0].portfolioValue).toBeGreaterThan(params.initialValue + params.monthlyContribution * 12);
    expect(projections[2].year).toBe(3);
    expect(projections[2].portfolioValue).toBeGreaterThan(projections[1].portfolioValue);
  });

  it("calculates Thai PIT progressive tax with deductions", () => {
    const input: ThaiTaxInput = {
      annualAssessableIncomeTHB: 1500000,
      standardExpenseDeductionTHB: 100000,
      personalAllowanceTHB: 60000,
      additionalDeductionsTHB: 100000, // e.g. RMF/SSF/Insurance
    };

    const taxResult = calculateThaiTax(input);

    expect(taxResult.assessableIncome).toBe(1500000);
    expect(taxResult.totalDeductions).toBe(260000);
    expect(taxResult.taxableIncome).toBe(1240000);
    // Brackets:
    // 0-150k: 0
    // 150k-300k: 150k * 0.05 = 7,500
    // 300k-500k: 200k * 0.10 = 20,000
    // 500k-750k: 250k * 0.15 = 37,500
    // 750k-1M: 250k * 0.20 = 50,000
    // 1M-1.24M: 240k * 0.25 = 60,000
    // Total: 7500 + 20000 + 37500 + 50000 + 60000 = 175,000
    expect(taxResult.taxPayableTHB).toBe(175000);
    expect(taxResult.effectiveRate).toBeCloseTo((175000 / 1500000) * 100, 2);
  });
});
