import React, { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Currency = "AUD" | "USD" | "THB";
export type Theme = "dark" | "light";

export const FX_RATES: Record<Currency, number> = {
  AUD: 1.0,
  USD: 0.69,
  THB: 23.5,
};

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (c: Currency) => void;
  formatCurrency: (amountInAud: number, decimals?: number) => string;
  theme: Theme;
  toggleTheme: () => void;
  isSyncing: boolean;
  triggerSync: () => Promise<void>;
  lastSynced: Date | null;
}

const CurrencyContext = createContext<CurrencyContextType | null>(null);

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrencyState] = useState<Currency>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("spark_currency");
      if (saved === "AUD" || saved === "USD" || saved === "THB") return saved;
    }
    return "AUD";
  });

  const [theme, setThemeState] = useState<Theme>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("spark_theme");
      if (saved === "light" || saved === "dark") return saved;
      if (document.documentElement.classList.contains("dark")) return "dark";
    }
    return "dark";
  });

  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSynced, setLastSynced] = useState<Date | null>(new Date());

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("spark_currency", currency);
    }
  }, [currency]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("spark_theme", theme);
      if (theme === "dark") {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    }
  }, [theme]);

  const toggleTheme = () => {
    setThemeState((t) => (t === "dark" ? "light" : "dark"));
  };

  const setCurrency = (c: Currency) => {
    setCurrencyState(c);
  };

  const triggerSync = async () => {
    setIsSyncing(true);
    await new Promise((resolve) => setTimeout(resolve, 800));
    setIsSyncing(false);
    setLastSynced(new Date());
  };

  const formatCurrency = (amountInAud: number, decimals = 0): string => {
    const rate = FX_RATES[currency] || 1.0;
    const converted = amountInAud * rate;
    const symbol = currency === "USD" ? "$" : currency === "THB" ? "฿" : "A$";
    return `${symbol}${Math.round(converted).toLocaleString("en-AU", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    })}`;
  };

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        setCurrency,
        formatCurrency,
        theme,
        toggleTheme,
        isSyncing,
        triggerSync,
        lastSynced,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const ctx = useContext(CurrencyContext);
  if (!ctx) {
    // Fallback if rendered outside provider
    return {
      currency: "AUD" as Currency,
      setCurrency: () => {},
      formatCurrency: (n: number, d = 0) =>
        `A$${Math.round(n).toLocaleString("en-AU", { minimumFractionDigits: d, maximumFractionDigits: d })}`,
      theme: "dark" as Theme,
      toggleTheme: () => {},
      isSyncing: false,
      triggerSync: async () => {},
      lastSynced: new Date(),
    };
  }
  return ctx;
}
