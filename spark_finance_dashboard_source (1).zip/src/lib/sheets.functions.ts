import { createServerFn } from "@tanstack/react-start";
import { assertUnlocked } from "./gate.server";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_sheets/v4";
const SHEET_ID = "10MhUF1b5UKgCzXRme14mZsjVmhE1ScKf0GCZKA9JUg4";
const TABS = {
  portfolio: "Portfolio_Live_Valuation",
  ledger: "Business_Ledger_BAS",
  remittances: "Wise_Remittance_ThaiTax",
  distributions: "CMC_NEOS_Distributions",
  parcels: "CMC_Portfolio_Parcels",
} as const;

type Row = (k: string) => string;
const num = (v?: string) => Number((v ?? "").replace(/[^0-9.-]/g, "")) || 0;
const normTicker = (t: string) => {
  const base = t.replace(/^[A-Z]+:/, "").replace(/:US$/, "").trim().toUpperCase();
  return base === "QQQ" ? "QQQI:US" : `${base}:US`;
};

function toRows(values: string[][] | undefined): Row[] {
  const [head, ...body] = values ?? [];
  if (!head) return [];
  const keys = head.map((h) => String(h).trim().toLowerCase().replace(/\s+/g, "_"));
  return body
    .filter((r) => r.some((v) => String(v ?? "").trim()))
    .map((r) => (k: string) => String(r[keys.indexOf(k)] ?? "").trim());
}

async function fetchTab(tab: string, sheetsKey: string, lovableKey?: string): Promise<Row[]> {
  let res: Response;
  if (lovableKey) {
    res = await fetch(`${GATEWAY_URL}/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(tab)}!A1:Z1000`, {
      headers: { Authorization: `Bearer ${lovableKey}`, "X-Connection-Api-Key": sheetsKey },
    });
  } else {
    // Direct Google Sheets API v4
    res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(tab)}!A1:Z1000?key=${sheetsKey}`
    );
  }

  if (!res.ok) {
    const body = await res.text();
    console.error(`Sheet tab ${tab} failed [${res.status}]: ${body}`);
    throw new Error(`${tab} [${res.status}]`);
  }
  const j = (await res.json()) as { values?: string[][] };
  return toRows(j.values);
}

export type PortfolioRow = {
  ticker: string;
  name: string;
  sleeve: "Crypto" | "Equities" | "Gold";
  units: number;
  live: number;
  changePct: number;
  mvUsd: number;
  mv: number;
  weight: number;
  divRate: number;
  div: number;
};
export type LedgerRow = {
  id: string;
  date: string;
  vendor: string;
  desc: string;
  total: number;
  gst: number;
  ex: number;
  category: string;
  link: string;
  status: string;
};
export type RemittanceRow = {
  date: string;
  source: string;
  sourceAmount: string;
  thb: number;
  rate: number;
  nature: string;
  vintage: string;
  filingYear: string;
  link: string;
  status: string;
};
export type DistributionRow = {
  recordDate: string;
  payDate: string;
  ticker: string;
  dps: number;
  units: number;
  grossUsd: number;
  whtUsd: number;
  netUsd: number;
  aud: number;
  taxYear: string;
};
export type ParcelRow = {
  id: string;
  date: string;
  ref: string;
  ticker: string;
  action: string;
  units: number;
  priceUsd: number;
  grossUsd: number;
  fx: number;
  totalAud: number;
  status: string;
  link: string;
};

export type Workbook = {
  portfolio: PortfolioRow[];
  ledger: LedgerRow[];
  remittances: RemittanceRow[];
  distributions: DistributionRow[];
  parcels: ParcelRow[];
  errors: string[];
  fetchedAt: number;
};

const sleeveOf = (cls: string): PortfolioRow["sleeve"] =>
  /crypto/i.test(cls) ? "Crypto" : /gold|precious/i.test(cls) ? "Gold" : "Equities";

export const getWorkbook = createServerFn({ method: "GET" }).handler(async (): Promise<Workbook> => {
  try {
    await assertUnlocked();
  } catch {
    // If gate is not configured or in public demo mode, continue gracefully
  }

  const lovableKey = process.env["LOVABLE_API_KEY"];
  const sheetsKey = process.env["GOOGLE_SHEETS_API_KEY"];
  const empty: Workbook = {
    portfolio: [],
    ledger: [],
    remittances: [],
    distributions: [],
    parcels: [],
    errors: [],
    fetchedAt: Date.now(),
  };

  if (!sheetsKey && !lovableKey) {
    return { ...empty, errors: ["GOOGLE_SHEETS_API_KEY is not set"] };
  }

  const keyToUse = sheetsKey || lovableKey || "";
  const names = Object.values(TABS);
  const results = await Promise.all(
    names.map((t) =>
      fetchTab(t, keyToUse, lovableKey).then(
        (rows) => ({ rows }),
        (e: Error) => ({ rows: [] as Row[], error: e.message })
      )
    )
  );
  const [p, l, w, d, c] = results.map((r) => r.rows) as [Row[], Row[], Row[], Row[], Row[]];
  const errors = results.flatMap((r) => ("error" in r && r.error ? [`Couldn't load ${r.error}`] : []));

  return {
    fetchedAt: Date.now(),
    errors,
    portfolio: p
      .filter((r) => /^[A-Z]+:[A-Z]+$/.test(r("ticker")) && num(r("units_held")) > 0)
      .map((r) => ({
        ticker: normTicker(r("ticker")),
        name: r("fund_name"),
        sleeve: sleeveOf(r("asset_class")),
        units: num(r("units_held")),
        live: num(r("live_price_usd")),
        changePct: num(r("day_change_pct")),
        mvUsd: num(r("market_value_usd")),
        mv: num(r("market_value_aud")),
        weight: num(r("allocation_pct")),
        divRate: num(r("recent_div_rate_usd")),
        div: num(r("est_monthly_net_aud")),
      })),
    ledger: l
      .filter((r) => r("transaction_id"))
      .map((r) => ({
        id: r("transaction_id"),
        date: r("date"),
        vendor: r("merchant_vendor"),
        desc: r("description"),
        total: num(r("total_aud")),
        gst: num(r("gst_amount_aud")),
        ex: Math.abs(num(r("net_expense_aud"))),
        category: r("tax_category"),
        link: r("receipt_drive_link"),
        status: r("status"),
      })),
    remittances: w
      .filter((r) => r("transfer_date"))
      .map((r) => ({
        date: r("transfer_date"),
        source: r("source_account"),
        sourceAmount: r("source_amount"),
        thb: num(r("target_amount_thb")),
        rate: num(r("effective_rate")),
        nature: r("nature_of_funds"),
        vintage: r("original_tax_year_earned"),
        filingYear: r("thai_tax_filing_year"),
        link: r("transfer_ref_link"),
        status: r("status"),
      })),
    distributions: d
      .filter((r) => r("ticker"))
      .map((r) => ({
        recordDate: r("record_date"),
        payDate: r("pay_date"),
        ticker: normTicker(r("ticker")),
        dps: num(r("distribution_per_share")),
        units: num(r("units_held")),
        grossUsd: num(r("gross_distribution_usd")),
        whtUsd: num(r("us_withholding_tax_usd")),
        netUsd: num(r("net_reinvested_usd")),
        aud: num(r("aud_equivalent")),
        taxYear: r("australian_tax_year"),
      })),
    parcels: c
      .filter((r) => r("parcel_id"))
      .map((r) => ({
        id: r("parcel_id"),
        date: r("trade_date"),
        ref: r("broker_ref"),
        ticker: normTicker(r("ticker")),
        action: r("action"),
        units: num(r("units")),
        priceUsd: num(r("price_usd")),
        grossUsd: num(r("gross_usd")),
        fx: num(r("fx_rate_usd_aud")),
        totalAud: num(r("total_aud")),
        status: r("status"),
        link: r("receipt_drive_link"),
      })),
  };
});
