// src/lib/finance-data.ts
// Connected to Master_Financial_Ledger (ID: 10MhUF1b5UKgCzXRme14mZsjVmhE1ScKf0GCZKA9JUg4)
// and Google Drive Root Archive Financials_Master (ID: 1UAAVQBsxWmGiOw4mwL1eMO0Lnnb0O4BU)

export const MASTER_FINANCIAL_SYSTEM = {
  spreadsheetName: "Master_Financial_Ledger",
  spreadsheetId: "10MhUF1b5UKgCzXRme14mZsjVmhE1ScKf0GCZKA9JUg4",
  spreadsheetUrl: "https://docs.google.com/spreadsheets/d/10MhUF1b5UKgCzXRme14mZsjVmhE1ScKf0GCZKA9JUg4/edit?usp=drivesdk",
  rootFolderId: "1UAAVQBsxWmGiOw4mwL1eMO0Lnnb0O4BU",
  rootFolderUrl: "https://drive.google.com/drive/folders/1UAAVQBsxWmGiOw4mwL1eMO0Lnnb0O4BU",
  tradeConfirmationsFolderId: "1JvEjpmdB4SkPhnak3Zlack1jcEHb-ykc",
  tradeConfirmationsFolderUrl: "https://drive.google.com/drive/folders/1JvEjpmdB4SkPhnak3Zlack1jcEHb-ykc",
  invoiceTemplatesFolderId: "1__cC4H7r57agCFxUNZJ-32YLx8VtYfJA",
  invoiceTemplatesFolderUrl: "https://drive.google.com/drive/folders/1__cC4H7r57agCFxUNZJ-32YLx8VtYfJA",
  tabs: {
    portfolio: "Portfolio_Live_Valuation",
    ledger: "Business_Ledger_BAS",
    remittances: "Wise_Remittance_ThaiTax",
    distributions: "CMC_NEOS_Distributions",
    parcels: "CMC_Portfolio_Parcels",
  },
};

export const aud = (n: number, d = 0) =>
  "A$" + n.toLocaleString("en-AU", { minimumFractionDigits: d, maximumFractionDigits: d });

// Tab: Portfolio_Live_Valuation (1,868 total units)
export const holdings = [
  {
    ticker: "BTCI:US",
    name: "NEOS Bitcoin High Income ETF",
    sleeve: "Crypto",
    units: 633,
    costUsd: 34.12,
    costAud: 49.05,
    live: 32.94,
    mv: 29903.57,
    mvUsd: 20851.02,
    weight: 28.60,
    divRate: 0.7184,
    div: 554.35,
  },
  {
    ticker: "NEHI:US",
    name: "NEOS Ethereum High Income ETF",
    sleeve: "Crypto",
    units: 590,
    costUsd: 32.06,
    costAud: 45.34,
    live: 31.07,
    mv: 26289.91,
    mvUsd: 18331.30,
    weight: 25.14,
    divRate: 0.8721,
    div: 627.24,
  },
  {
    ticker: "IAUI:US",
    name: "NEOS Gold High Income ETF",
    sleeve: "Gold",
    units: 254,
    costUsd: 56.39,
    costAud: 80.23,
    live: 48.05,
    mv: 17503.42,
    mvUsd: 12204.70,
    weight: 16.74,
    divRate: 0.5011,
    div: 155.16,
  },
  {
    ticker: "SPYI:US",
    name: "NEOS S&P 500 High Income ETF",
    sleeve: "Equities",
    units: 199,
    costUsd: 52.00,
    costAud: 73.45,
    live: 53.86,
    mv: 15371.46,
    mvUsd: 10718.14,
    weight: 14.70,
    divRate: 0.5338,
    div: 129.49,
  },
  {
    ticker: "QQQI:US",
    name: "NEOS Nasdaq-100 High Income ETF",
    sleeve: "Equities",
    units: 192,
    costUsd: 53.59,
    costAud: 75.70,
    live: 56.25,
    mv: 15488.86,
    mvUsd: 10800.00,
    weight: 14.81,
    divRate: 0.6339,
    div: 148.37,
  },
];

export const sleeves = [
  { name: "Crypto", actual: 53.7, min: 45, max: 55, tone: "warning", status: "Balanced (~53.7%) — Crypto Reinvestment Normal" },
  { name: "Equities", actual: 29.5, min: 30, max: 35, tone: "warning", status: "Underweight (Target 30-35%) — Primary Reinvestment Priority" },
  { name: "Gold", actual: 16.7, min: 15, max: 20, tone: "success", status: "Balanced (16.7%) — Target Maintained" },
] as const;

export const PORTFOLIO_VALUE = 104557.23;
export const PORTFOLIO_VALUE_USD = 72905.16;
export const TOTAL_UNITS = 1868;
export const EST_MONTHLY_DIV_AUD = 1614.61;

// Tab: Business_Ledger_BAS (SHIPAUS Invoices & Receipts)
export const invoices = [
  { id: "TXN-2024-001", date: "2024-10-01", vendor: "SHIPAUS Pty Ltd", desc: "Bareboat Charter JAS 2024 (MV COM 4 - Q1 FY25)", ex: 6500, gst: 650, total: 7150, category: "Vessel_Charter_Income", link: "https://drive.google.com/file/d/10HZyCEY7NvxMVkpE-FOnebMxlOVED8zt/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2024-002", date: "2024-12-27", vendor: "SHIPAUS Pty Ltd", desc: "Bareboat Charter OND 2024 (MV COM 4 - Q2 FY25)", ex: 6500, gst: 650, total: 7150, category: "Vessel_Charter_Income", link: "https://drive.google.com/file/d/1qcEB9oMCa4UN9OYcnUN2WOZHmEAfyWKs/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2025-001", date: "2025-03-20", vendor: "SHIPAUS Pty Ltd", desc: "Bareboat Charter JFM 2025 (MV COM 4 - Q3 FY25)", ex: 6500, gst: 650, total: 7150, category: "Vessel_Charter_Income", link: "https://drive.google.com/file/d/1DJeDWPwanKLUtrqnzT_fixS52Qhcxsfq/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2025-002", date: "2025-06-18", vendor: "SHIPAUS Pty Ltd", desc: "Bareboat Charter AMJ 2025 (MV COM 4 - Q4 FY25)", ex: 6500, gst: 650, total: 7150, category: "Vessel_Charter_Income", link: "https://drive.google.com/file/d/1RR9s3XT0Uos6QfNNk_Li7CuSIq-9a26_/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2025-003", date: "2025-06-18", vendor: "SHIPAUS Pty Ltd", desc: "Annual ROI 2025 (PAHE & NEWCHE Equipment Hire - FY25)", ex: 20000, gst: 2000, total: 22000, category: "Equipment_Hire_Income", link: "https://drive.google.com/file/d/1Suu4U02Rgehi2A8CrlB7WpApzvPNv4Hf/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2025-004", date: "2025-09-12", vendor: "SHIPAUS Pty Ltd", desc: "Bareboat Charter JAS 2025 (MV COM 4 - Q1 FY26)", ex: 6500, gst: 650, total: 7150, category: "Vessel_Charter_Income", link: "https://drive.google.com/file/d/1fB74ECd0EkLUHH0AocqJR4j4091rlDn6/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2025-005", date: "2025-12-15", vendor: "SHIPAUS Pty Ltd", desc: "Bareboat Charter OND 2025 (MV COM 4 - Q2 FY26)", ex: 6500, gst: 650, total: 7150, category: "Vessel_Charter_Income", link: "https://drive.google.com/file/d/1n2n63w3eHpy3vvdKB8BZc_EUStY7e53j/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2026-001", date: "2026-03-16", vendor: "SHIPAUS Pty Ltd", desc: "Bareboat Charter JFM 2026 (MV COM 4 - Q3 FY26)", ex: 6500, gst: 650, total: 7150, category: "Vessel_Charter_Income", link: "https://drive.google.com/file/d/1Nj2SZvCn3T349vALHbLmqN-w3ywLu9Bu/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2026-002", date: "2026-03-16", vendor: "SHIPAUS Pty Ltd", desc: "Annual ROI 2026 (PAHE & NEWCHE Equipment Hire - FY26)", ex: 20000, gst: 2000, total: 22000, category: "Equipment_Hire_Income", link: "https://drive.google.com/file/d/1tlUSX7DBeqTO9VpivGeNQkHzk4_iYS9e/view?usp=drivesdk", status: "Paid" },
  { id: "TXN-2026-003", date: "2026-04-18", vendor: "CMC Markets Stockbroking Limited", desc: "Tax Tools Plus Annual Subscription (INV-202642693)", ex: 90, gst: 9, total: 99, category: "Software_Subscription_Expense", link: "https://mail.google.com/mail/?authuser=ollycav@gmail.com#all/thread-f:1878088374411574695", status: "Paid" },
];

// Tab: Wise_Remittance_ThaiTax (Orders Paw 161 & 162)
export const remittances = [
  { date: "2025-01-15", source: "Wise USD Account (TeachThis Royalties)", sourceAmount: "1500.00 USD", thb: 51750, rate: 34.5, nature: "Educational Publishing Royalties", vintage: "2024", filingYear: "2025", link: "https://drive.google.com/file/d/1j80OYJek0H1NhmASwGyIJJJVngkCJ09R/view?usp=drivesdk", status: "Remitted_Documented" },
  { date: "2025-04-10", source: "Wise USD Account (TeachThis Royalties)", sourceAmount: "2000.00 USD", thb: 72400, rate: 36.2, nature: "Educational Publishing Royalties", vintage: "2024", filingYear: "2025", link: "https://drive.google.com/file/d/1j80OYJek0H1NhmASwGyIJJJVngkCJ09R/view?usp=drivesdk", status: "Remitted_Documented" },
  { date: "2025-07-22", source: "Wise AUD Account (Pre-2024 Capital Savings)", sourceAmount: "3000.00 AUD", thb: 70800, rate: 23.6, nature: "Grandfathered Savings Pre-2024", vintage: "Pre-2024", filingYear: "2025", link: "https://drive.google.com/file/d/19cZrViei0QAXzDeent2s3kf13XUWXoDs/view?usp=drivesdk", status: "Exempt_Paw_162/2566" },
  { date: "2025-10-18", source: "Wise USD Account (TeachThis Royalties)", sourceAmount: "2500.00 USD", thb: 91250, rate: 36.5, nature: "Educational Publishing Royalties", vintage: "2025", filingYear: "2025", link: "https://drive.google.com/file/d/1j80OYJek0H1NhmASwGyIJJJVngkCJ09R/view?usp=drivesdk", status: "Remitted_Documented" },
  { date: "2026-02-14", source: "Wise AUD Account (Vessel Charter Profit)", sourceAmount: "2500.00 AUD", thb: 58750, rate: 23.5, nature: "Commercial Vessel Lease Income", vintage: "2025", filingYear: "2026", link: "https://drive.google.com/file/d/19cZrViei0QAXzDeent2s3kf13XUWXoDs/view?usp=drivesdk", status: "Remitted_Documented" },
];
