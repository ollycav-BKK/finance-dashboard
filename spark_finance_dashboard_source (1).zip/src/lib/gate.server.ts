import { useSession } from "@tanstack/react-start/server";
import { createHash, timingSafeEqual } from "node:crypto";

type GateSession = { unlocked?: boolean };

export function gateSessionConfig() {
  return {
    password: process.env["SESSION_SECRET"]!,
    name: "spark-gate",
    maxAge: 60 * 60 * 24 * 30,
    cookie: { httpOnly: true, secure: process.env["NODE_ENV"] === "production", sameSite: "lax" as const, path: "/" },
  };
}

export function getGateSession() {
  return useSession<GateSession>(gateSessionConfig());
}

export async function isUnlocked() {
  const s = await getGateSession();
  return s.data.unlocked === true;
}

export async function assertUnlocked() {
  if (!(await isUnlocked())) throw new Response("Locked", { status: 401 });
}

export function passcodeMatches(input: string) {
  const expected = process.env["SITE_PASSCODE"];
  if (!expected) throw new Error("SITE_PASSCODE is not set");
  const a = createHash("sha256").update(input, "utf8").digest();
  const b = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(a, b);
}
