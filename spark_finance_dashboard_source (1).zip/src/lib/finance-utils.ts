// src/lib/finance-utils.ts

export interface PortfolioHolding {
  ticker: string;
  name: string;
  shares: number;
  avgCost: number;
  currentPrice: number;
  annualDividendYield: number; // e.g. 0.08 for 8%
  category: "ETF" | "Option Income" | "Crypto" | "Gold" | "Cash" | "Marine";
}

// 1. Portfolio KPIs
export function calculatePortfolioKPIs(holdings: PortfolioHolding[]) {
  const totalValue = holdings.reduce(
    (sum, h) => sum + h.shares * h.currentPrice,
    0
  );
  const totalCost = holdings.reduce(
    (sum, h) => sum + h.shares * h.avgCost,
    0
  );
  const totalGainLoss = totalValue - totalCost;
  const totalGainLossPct = totalCost > 0 ? (totalGainLoss / totalCost) * 100 : 0;

  const projectedAnnualIncome = holdings.reduce(
    (sum, h) => sum + h.shares * h.currentPrice * h.annualDividendYield,
    0
  );
  const projectedMonthlyIncome = projectedAnnualIncome / 12;

  return {
    totalValue,
    totalCost,
    totalGainLoss,
    totalGainLossPct,
    projectedAnnualIncome,
    projectedMonthlyIncome,
  };
}

// 2. Compounding / DRIP Projection Calculator
export interface ProjectionParams {
  initialValue: number;
  monthlyContribution: number;
  annualYield: number; // e.g. 0.08
  annualGrowthRate: number; // e.g. 0.03
  years: number;
  reinvestDividends: boolean;
}

export interface YearProjection {
  year: number;
  portfolioValue: number;
  annualIncome: number;
  totalInvested: number;
}

export function generateProjections(params: ProjectionParams): YearProjection[] {
  const {
    initialValue,
    monthlyContribution,
    annualYield,
    annualGrowthRate,
    years,
    reinvestDividends,
  } = params;

  const data: YearProjection[] = [];
  let currentValue = initialValue;
  let totalInvested = initialValue;

  for (let y = 1; y <= years; y++) {
    for (let m = 1; m <= 12; m++) {
      currentValue += monthlyContribution;
      totalInvested += monthlyContribution;

      // Monthly capital appreciation
      currentValue *= 1 + annualGrowthRate / 12;

      // Dividend generation
      const monthlyDiv = (currentValue * annualYield) / 12;
      if (reinvestDividends) {
        currentValue += monthlyDiv;
      }
    }

    data.push({
      year: y,
      portfolioValue: Math.round(currentValue),
      annualIncome: Math.round(currentValue * annualYield),
      totalInvested: Math.round(totalInvested),
    });
  }

  return data;
}

// 3. Thai Personal Income Tax Calculator (PIT Brackets)
export interface ThaiTaxInput {
  annualAssessableIncomeTHB: number;
  standardExpenseDeductionTHB?: number; // Standard 50% up to 100,000 THB
  personalAllowanceTHB?: number; // Standard 60,000 THB
  additionalDeductionsTHB?: number; // Social security, provident fund, insurance, etc.
}

export function calculateThaiTax(input: ThaiTaxInput) {
  const standardExpense = Math.min(
    input.annualAssessableIncomeTHB * 0.5,
    input.standardExpenseDeductionTHB ?? 100000
  );
  const personalAllowance = input.personalAllowanceTHB ?? 60000;
  const otherDeductions = input.additionalDeductionsTHB ?? 0;

  const totalDeductions = standardExpense + personalAllowance + otherDeductions;
  const taxableIncome = Math.max(0, input.annualAssessableIncomeTHB - totalDeductions);

  // Progressive Tax Brackets (Thailand PIT)
  const brackets = [
    { limit: 150000, rate: 0.0 },
    { limit: 300000, rate: 0.05 },
    { limit: 500000, rate: 0.1 },
    { limit: 750000, rate: 0.15 },
    { limit: 1000000, rate: 0.2 },
    { limit: 2000000, rate: 0.25 },
    { limit: 5000000, rate: 0.3 },
    { limit: Infinity, rate: 0.35 },
  ];

  let tax = 0;
  let previousLimit = 0;

  for (const b of brackets) {
    if (taxableIncome > previousLimit) {
      const taxableInBracket = Math.min(taxableIncome, b.limit) - previousLimit;
      tax += taxableInBracket * b.rate;
      previousLimit = b.limit;
    } else {
      break;
    }
  }

  const effectiveRate = input.annualAssessableIncomeTHB > 0 
    ? (tax / input.annualAssessableIncomeTHB) * 100 
    : 0;

  return {
    assessableIncome: input.annualAssessableIncomeTHB,
    totalDeductions,
    taxableIncome,
    taxPayableTHB: Math.round(tax),
    effectiveRate: Number(effectiveRate.toFixed(2)),
  };
}
