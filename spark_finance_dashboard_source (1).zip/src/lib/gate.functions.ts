import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getGateSession, passcodeMatches } from "./gate.server";

export const unlockSite = createServerFn({ method: "POST" })
  .validator((d: unknown) => z.object({ passcode: z.string().min(1).max(200) }).parse(d))
  .handler(async ({ data }) => {
    if (!passcodeMatches(data.passcode)) return { ok: false as const };
    const s = await getGateSession();
    await s.update({ unlocked: true });
    return { ok: true as const };
  });

export const lockSite = createServerFn({ method: "POST" }).handler(async () => {
  const s = await getGateSession();
  await s.clear();
  return { ok: true as const };
});
