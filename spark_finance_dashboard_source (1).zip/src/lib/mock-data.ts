// src/lib/mock-data.ts
// Primary dataset aligned with Master_Financial_Ledger (10MhUF1b5UKgCzXRme14mZsjVmhE1ScKf0GCZKA9JUg4)
// and Google Drive Archive Financials_Master (1UAAVQBsxWmGiOw4mwL1eMO0Lnnb0O4BU)
import type { PortfolioHolding } from "./finance-utils";

export const MASTER_FINANCIAL_SYSTEM = {
  spreadsheetName: "Master_Financial_Ledger",
  spreadsheetId: "10MhUF1b5UKgCzXRme14mZsjVmhE1ScKf0GCZKA9JUg4",
  spreadsheetUrl: "https://docs.google.com/spreadsheets/d/10MhUF1b5UKgCzXRme14mZsjVmhE1ScKf0GCZKA9JUg4/edit?usp=drivesdk",
  rootFolderId: "1UAAVQBsxWmGiOw4mwL1eMO0Lnnb0O4BU",
  rootFolderUrl: "https://drive.google.com/drive/folders/1UAAVQBsxWmGiOw4mwL1eMO0Lnnb0O4BU",
  tradeConfirmationsFolderId: "1JvEjpmdB4SkPhnak3Zlack1jcEHb-ykc",
  tradeConfirmationsFolderUrl: "https://drive.google.com/drive/folders/1JvEjpmdB4SkPhnak3Zlack1jcEHb-ykc",
  invoiceTemplatesFolderId: "1__cC4H7r57agCFxUNZJ-32YLx8VtYfJA",
  invoiceTemplatesFolderUrl: "https://drive.google.com/drive/folders/1__cC4H7r57agCFxUNZJ-32YLx8VtYfJA",
};

export const INITIAL_HOLDINGS: PortfolioHolding[] = [
  {
    ticker: "BTCI:US",
    name: "NEOS Bitcoin High Income ETF",
    shares: 633,
    avgCost: 34.12, // USD (A$49.05)
    currentPrice: 32.94, // USD
    annualDividendYield: 0.262, // ~26.2%
    category: "Option Income",
  },
  {
    ticker: "NEHI:US",
    name: "NEOS Ethereum High Income ETF",
    shares: 590,
    avgCost: 32.06, // USD (A$45.34)
    currentPrice: 31.07, // USD
    annualDividendYield: 0.337, // ~33.7%
    category: "Option Income",
  },
  {
    ticker: "IAUI:US",
    name: "NEOS Gold High Income ETF",
    shares: 254,
    avgCost: 56.39, // USD (A$80.23)
    currentPrice: 48.05, // USD
    annualDividendYield: 0.125, // ~12.5%
    category: "ETF",
  },
  {
    ticker: "SPYI:US",
    name: "NEOS S&P 500 High Income ETF",
    shares: 199,
    avgCost: 52.00, // USD (A$73.45)
    currentPrice: 53.86, // USD
    annualDividendYield: 0.119, // ~11.9%
    category: "Option Income",
  },
  {
    ticker: "QQQI:US",
    name: "NEOS Nasdaq-100 High Income ETF",
    shares: 192,
    avgCost: 53.59, // USD (A$75.70)
    currentPrice: 56.25, // USD
    annualDividendYield: 0.135, // ~13.5%
    category: "Option Income",
  },
];

export const INITIAL_CALENDAR_EVENTS = [
  { id: "1", date: "2026-10-21", title: "NEOS Distribution Declaration (BTCI, NEHI, IAUI, SPYI, QQQI)", type: "dividend", amount: "A$1,614.61" },
  { id: "2", date: "2026-11-18", title: "BAS Audit Review (Q1 FY27 pre-lodgement)", type: "compliance", amount: "—" },
  { id: "3", date: "2026-11-25", title: "ATO BAS Q1 FY27 Due (GST Box 1A lodgement)", type: "payout", amount: "A$2,650.00" },
  { id: "4", date: "2026-12-20", title: "NEOS Monthly Dividend Payout", type: "dividend", amount: "A$1,614.61" },
  { id: "5", date: "2027-01-01", title: "Thai PIT Filing Window Opens (P.N.D.90)", type: "tax", amount: "—" },
  { id: "6", date: "2027-01-05", title: "Marine Charter Q3 FY27 Invoicing (MV COM 4)", type: "business", amount: "A$7,150.00" },
];

export const INITIAL_MARINE_METRICS = {
  activeRentals: 4,
  monthlyRevenue: 3833, // A$46,000 / 12
  operatingExpenses: 950,
  netOperatingIncome: 2883,
  fleetUtilizationPct: 98.5,
};
