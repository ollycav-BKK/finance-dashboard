import { createServerFn } from "@tanstack/react-start";
import { assertUnlocked } from "./gate.server";

export const FALLBACK_USD_AUD = 1.43;
const TICKERS = ["BTCI", "NEHI", "IAUI", "SPYI", "QQQI"];

type Quote = { price: number; prevClose: number; time: number };

async function quote(symbol: string): Promise<Quote | null> {
  try {
    const res = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=5d&interval=1d`, {
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    if (!res.ok) return null;
    const j = (await res.json()) as { chart?: { result?: { meta?: { regularMarketPrice?: number; chartPreviousClose?: number; previousClose?: number; regularMarketTime?: number } }[] } };
    const m = j.chart?.result?.[0]?.meta;
    if (!m?.regularMarketPrice) return null;
    return { price: m.regularMarketPrice, prevClose: m.previousClose ?? m.chartPreviousClose ?? m.regularMarketPrice, time: (m.regularMarketTime ?? 0) * 1000 };
  } catch (e) {
    console.error("Quote failed", symbol, e);
    return null;
  }
}

export type MarketData = {
  usdAud: number;
  fxLive: boolean;
  prices: Record<string, { price: number; changePct: number }>;
  asOf: number;
};

export const getMarketData = createServerFn({ method: "GET" }).handler(async (): Promise<MarketData> => {
  await assertUnlocked();
  const [fx, ...qs] = await Promise.all([quote("AUDUSD=X"), ...TICKERS.map(quote)]);
  const prices: MarketData["prices"] = {};
  let asOf = 0;
  TICKERS.forEach((t, i) => {
    const q = qs[i];
    if (q) {
      prices[`${t}:US`] = { price: q.price, changePct: q.prevClose ? ((q.price - q.prevClose) / q.prevClose) * 100 : 0 };
      asOf = Math.max(asOf, q.time);
    }
  });
  return { usdAud: fx ? 1 / fx.price : FALLBACK_USD_AUD, fxLive: !!fx, prices, asOf };
});
