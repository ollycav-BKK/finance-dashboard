// finance-engine.ts
// Pure client-side calculations for Portfolio, DRIP Projections, and Thai Tax Assessment
// Connected to Master_Financial_Ledger (10MhUF1b5UKgCzXRme14mZsjVmhE1ScKf0GCZKA9JUg4)

// ==========================================
// 1. DATA TYPES
// ==========================================

export interface Holding {
  id: string;
  ticker: string;
  name: string;
  assetClass: "Covered-Call ETF" | "Equity" | "Fixed Income" | "Cash";
  shares: number;
  averageCost: number; // in reporting currency (AUD)
  currentPrice: number; // in reporting currency (AUD)
  annualDividendPerShare: number; // in reporting currency (AUD)
}

export interface ProjectionInputs {
  initialCapital: number;
  monthlyContribution: number;
  annualDividendYieldPercent: number;
  annualPriceGrowthPercent: number;
  years: number;
  dripEnabled: boolean;
}

export interface YearProjection {
  year: number;
  startBalance: number;
  contributions: number;
  dividendsEarned: number;
  priceAppreciation: number;
  endBalance: number;
  cumulativeDividends: number;
  cumulativeContributions: number;
}

export interface ThaiTaxBracket {
  range: string;
  min: number;
  max: number | null;
  rate: number;
  taxInBracket: number;
}

export interface ThaiTaxResult {
  grossRemittance: number;
  standardDeduction: number;
  personalAllowance: number;
  netTaxableIncome: number;
  totalTax: number;
  effectiveTaxRate: number;
  brackets: ThaiTaxBracket[];
}

// ==========================================
// 2. SEED PORTFOLIO DATA (MASTER FINANCIAL LEDGER - 1,868 UNITS)
// ==========================================

export const INITIAL_HOLDINGS: Holding[] = [
  {
    id: "1",
    ticker: "BTCI:US",
    name: "NEOS Bitcoin High Income ETF",
    assetClass: "Covered-Call ETF",
    shares: 633,
    averageCost: 49.05, // A$
    currentPrice: 47.24, // A$ ($32.94 USD @ 1.434)
    annualDividendPerShare: 10.51, // ~A$554.35 / mo
  },
  {
    id: "2",
    ticker: "NEHI:US",
    name: "NEOS Ethereum High Income ETF",
    assetClass: "Covered-Call ETF",
    shares: 590,
    averageCost: 45.34, // A$
    currentPrice: 44.56, // A$ ($31.07 USD @ 1.434)
    annualDividendPerShare: 12.76, // ~A$627.24 / mo
  },
  {
    id: "3",
    ticker: "IAUI:US",
    name: "NEOS Gold High Income ETF",
    assetClass: "Equity",
    shares: 254,
    averageCost: 80.23, // A$
    currentPrice: 68.91, // A$ ($48.05 USD @ 1.434)
    annualDividendPerShare: 7.33, // ~A$155.16 / mo
  },
  {
    id: "4",
    ticker: "SPYI:US",
    name: "NEOS S&P 500 High Income ETF",
    assetClass: "Covered-Call ETF",
    shares: 199,
    averageCost: 73.45, // A$
    currentPrice: 77.24, // A$ ($53.86 USD @ 1.434)
    annualDividendPerShare: 7.81, // ~A$129.49 / mo
  },
  {
    id: "5",
    ticker: "QQQI:US",
    name: "NEOS Nasdaq-100 High Income ETF",
    assetClass: "Covered-Call ETF",
    shares: 192,
    averageCost: 75.70, // A$
    currentPrice: 80.67, // A$ ($56.25 USD @ 1.434)
    annualDividendPerShare: 9.27, // ~A$148.37 / mo
  },
];

// ==========================================
// 3. PORTFOLIO METRICS
// ==========================================

export function calculatePortfolioMetrics(holdings: Holding[]) {
  return holdings.reduce(
    (acc, item) => {
      const marketValue = item.shares * item.currentPrice;
      const costBasis = item.shares * item.averageCost;
      const annualIncome = item.shares * item.annualDividendPerShare;

      acc.totalMarketValue += marketValue;
      acc.totalCostBasis += costBasis;
      acc.totalAnnualIncome += annualIncome;
      return acc;
    },
    {
      totalMarketValue: 0,
      totalCostBasis: 0,
      totalAnnualIncome: 0,
      totalGainLoss: 0,
      gainLossPercent: 0,
      blendedYieldPercent: 0,
      monthlyIncome: 0,
    }
  );
}

export function computePortfolioSummary(holdings: Holding[]) {
  const totals = calculatePortfolioMetrics(holdings);
  totals.totalGainLoss = totals.totalMarketValue - totals.totalCostBasis;
  totals.gainLossPercent =
    totals.totalCostBasis > 0 ? (totals.totalGainLoss / totals.totalCostBasis) * 100 : 0;
  totals.blendedYieldPercent =
    totals.totalMarketValue > 0 ? (totals.totalAnnualIncome / totals.totalMarketValue) * 100 : 0;
  totals.monthlyIncome = totals.totalAnnualIncome / 12;

  return totals;
}

// ==========================================
// 4. DRIP & COMPOUND PROJECTIONS
// ==========================================

export function calculateProjections(inputs: ProjectionInputs): YearProjection[] {
  const {
    initialCapital,
    monthlyContribution,
    annualDividendYieldPercent,
    annualPriceGrowthPercent,
    years,
    dripEnabled,
  } = inputs;

  const dividendYield = annualDividendYieldPercent / 100;
  const priceGrowth = annualPriceGrowthPercent / 100;
  const annualContribution = monthlyContribution * 12;

  const projections: YearProjection[] = [];
  let currentBalance = initialCapital;
  let cumulativeDividends = 0;
  let cumulativeContributions = initialCapital;

  for (let y = 1; y <= years; y++) {
    const startBalance = currentBalance;
    const effectiveBase = startBalance + annualContribution / 2;
    const dividendsEarned = effectiveBase * dividendYield;
    const priceAppreciation = effectiveBase * priceGrowth;

    cumulativeDividends += dividendsEarned;
    cumulativeContributions += annualContribution;

    if (dripEnabled) {
      currentBalance = startBalance + annualContribution + dividendsEarned + priceAppreciation;
    } else {
      currentBalance = startBalance + annualContribution + priceAppreciation;
    }

    projections.push({
      year: y,
      startBalance: Math.round(startBalance),
      contributions: Math.round(annualContribution),
      dividendsEarned: Math.round(dividendsEarned),
      priceAppreciation: Math.round(priceAppreciation),
      endBalance: Math.round(currentBalance),
      cumulativeDividends: Math.round(cumulativeDividends),
      cumulativeContributions: Math.round(cumulativeContributions),
    });
  }

  return projections;
}

// ==========================================
// 5. THAI PERSONAL INCOME TAX (PIT)
// ==========================================

const THAI_TAX_TABLE = [
  { min: 0, max: 150_000, rate: 0.0 },
  { min: 150_000, max: 300_000, rate: 0.05 },
  { min: 300_000, max: 500_000, rate: 0.1 },
  { min: 500_000, max: 750_000, rate: 0.15 },
  { min: 750_000, max: 1_000_000, rate: 0.2 },
  { min: 1_000_000, max: 2_000_000, rate: 0.25 },
  { min: 2_000_000, max: 5_000_000, rate: 0.3 },
  { min: 5_000_000, max: null, rate: 0.35 },
];

export function calculateThaiTax(
  grossRemittanceTHB: number,
  customDeduction?: number,
  customAllowance?: number
): ThaiTaxResult {
  const standardDeduction =
    customDeduction !== undefined
      ? customDeduction
      : Math.min(grossRemittanceTHB * 0.5, 100_000);

  const personalAllowance = customAllowance !== undefined ? customAllowance : 60_000;
  const netTaxableIncome = Math.max(0, grossRemittanceTHB - standardDeduction - personalAllowance);

  let totalTax = 0;
  const bracketResults: ThaiTaxBracket[] = [];

  for (const b of THAI_TAX_TABLE) {
    if (netTaxableIncome <= b.min) {
      bracketResults.push({
        range: b.max ? `${(b.min / 1000).toFixed(0)}k - ${(b.max / 1000).toFixed(0)}k` : `> 5M`,
        min: b.min,
        max: b.max,
        rate: b.rate,
        taxInBracket: 0,
      });
      continue;
    }

    const taxableInBracket =
      b.max !== null
        ? Math.min(netTaxableIncome, b.max) - b.min
        : netTaxableIncome - b.min;

    const taxInBracket = taxableInBracket * b.rate;
    totalTax += taxInBracket;

    bracketResults.push({
      range: b.max ? `${(b.min / 1000).toFixed(0)}k - ${(b.max / 1000).toFixed(0)}k` : `> 5M`,
      min: b.min,
      max: b.max,
      rate: b.rate,
      taxInBracket: Math.round(taxInBracket),
    });
  }

  const effectiveTaxRate =
    grossRemittanceTHB > 0 ? (totalTax / grossRemittanceTHB) * 100 : 0;

  return {
    grossRemittance: grossRemittanceTHB,
    standardDeduction: Math.round(standardDeduction),
    personalAllowance: Math.round(personalAllowance),
    netTaxableIncome: Math.round(netTaxableIncome),
    totalTax: Math.round(totalTax),
    effectiveTaxRate: Number(effectiveTaxRate.toFixed(2)),
    brackets: bracketResults,
  };
}
