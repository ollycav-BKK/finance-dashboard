import { createOpenAI } from "@ai-sdk/openai";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createLovableAiGatewayRunIdFetch, getLovableAiGatewayRunId, withLovableAiGatewayRunIdHeader } from "./run-id.server";
import { holdings, sleeves, invoices, remittances, templates, PORTFOLIO_VALUE } from "@/lib/finance-data";

const MODEL = "openai/gpt-6-astra";
const BASE_URL = "https://ai.gateway.lovable.dev/v1";

function buildInstructions() {
  const ledger = {
    profile: {
      name: "Oreglio (Olly) Cavallaro", status: "Australian sole trader, ABN 81 315 008 648",
      residency: "Thai tax resident, Bangkok (>180 days/yr), Thai TIN 0991003515691", reportingCurrency: "AUD",
      today: new Date().toISOString().slice(0, 10),
    },
    neosPortfolio: {
      marketValueAud: PORTFOLIO_VALUE, costBasisAud: 101555, netGainAud: 468,
      monthlyNetDistributionAud: 1463, annualRunRateAud: 17556, holdings, sleeves,
      reinvestmentRule: "Route dividend cash to the most underweight sleeve; currently Equities (SPYI/QQQI ~51/49 split).",
    },
    marineOperations: {
      client: "SHIPAUS Pty Ltd", annualRevenueExGstAud: 46000, gstLiabilityBox1AAud: 4600, grossInvoicedIncGstAud: 50600,
      revenueBreakdownExGstAud: { mvCom4Bareboat: 26000, paheRoi: 20000 },
      contracts: templates, gstRate: 0.1,
      invoices: invoices.map((i) => ({ ...i, gst: i.ex * 0.1, total: i.ex * 1.1 })),
      note: "Marine income and profit analysis must use ex-GST revenue. GST is tracked separately as an ATO liability; gross invoices reconcile to bank deposits. Invoice amounts in the ledger are sample entries pending real data.",
    },
    thaiTax: {
      rules: {
        "Paw 162/2566": "Foreign income earned before 1 Jan 2024 is exempt when remitted.",
        "Paw 161/2566": "Foreign income earned from 2024 onward is assessable when remitted by a Thai resident (report on P.N.D.90/91).",
      },
      filingWindow: "1 Jan – 31 Mar annually", remittances,
      note: "Remittance history is sample data pending real Wise records.",
    },
    calendar: {
      bas: { "Q1 FY27": "2026-11-25 (audit 2026-11-18)", "Q2 FY27": "2027-02-28", "Q3 FY27": "2027-04-28", "Q4 FY27": "2027-07-28" },
      nextNeosDeclaration: "~2026-10-21",
    },
  };
  return `You are Spark Advisor, the in-app financial analyst inside Spark Finance OS.
Answer ONLY from the ledger JSON below plus well-established general rules (ATO GST/BAS, Thai remittance orders). 
Rules:
- Ground every number in the ledger; show the arithmetic briefly when you compute something.
- If data is missing, marked as sample, or the question needs info you don't have, say so plainly rather than inventing.
- End with 1–3 concrete, actionable next steps as a short list.
- Be concise: aim for under 250 words, use markdown tables when comparing figures. Currency in A$ unless USD is specified.
- You are not a licensed adviser; for material tax decisions add one short line suggesting confirmation with a registered tax agent.

LEDGER:
${JSON.stringify(ledger)}`;
}

export async function handleAdvisorChat(request: Request) {
  let messages: UIMessage[];
  try {
    const body = (await request.json()) as { messages?: unknown };
    if (!Array.isArray(body.messages)) throw new Error();
    messages = body.messages as UIMessage[];
  } catch {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }
  const apiKey = process.env['LOVABLE_API_KEY'];
  if (!apiKey) return Response.json({ error: "AI is not configured" }, { status: 500 });

  const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
  const provider = createOpenAI({
    baseURL: BASE_URL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });

  const result = streamText({
    model: provider.responses(MODEL),
    instructions: buildInstructions(),
    messages: await convertToModelMessages(messages),
    abortSignal: request.signal,
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: "medium",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });

  return withLovableAiGatewayRunIdHeader(
    result.toUIMessageStreamResponse({
      originalMessages: messages,
      sendReasoning: true,
      onError: (err) => {
        const e = err as { statusCode?: number; message?: string };
        if (e?.statusCode === 402) return "Out of AI credits — add credits in Settings → Plans & credits.";
        if (e?.statusCode === 429) return "Too many requests right now — please wait a moment and try again.";
        if (e?.statusCode === 403) return "AI access is blocked for this workspace.";
        return "The advisor couldn't answer that. Please try again.";
      },
    }),
    runIdFetch,
  );
}
