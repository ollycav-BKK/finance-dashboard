import { useQuery, useQueryClient, useIsFetching } from "@tanstack/react-query";
import { getWorkbook } from "./sheets.functions";
import { getMarketData } from "./market.functions";
import { holdings as fallbackHoldings, sleeves as fallbackSleeves } from "./finance-data";

export function useWorkbook() {
  const q = useQuery({ queryKey: ["workbook"], queryFn: () => getWorkbook(), staleTime: 5 * 60_000 });
  return { wb: q.data ?? null, loading: q.isLoading, fetching: q.isFetching, errors: q.data?.errors ?? [] };
}

export function useRefreshData() {
  const qc = useQueryClient();
  const busy = useIsFetching() > 0;
  return { busy, refresh: () => Promise.all([qc.invalidateQueries({ queryKey: ["workbook"] }), qc.invalidateQueries({ queryKey: ["market"] })]) };
}

export function useLedger() {
  const { wb, loading, errors } = useWorkbook();
  return { rows: wb?.ledger ?? [], error: errors.find((e) => e.includes("Ledger")) ?? null, loading };
}

export function useMarket() {
  const q = useQuery({ queryKey: ["market"], queryFn: () => getMarketData(), staleTime: 60_000, refetchInterval: 5 * 60_000 });
  return { market: q.data ?? null, loading: q.isLoading };
}

export function useHoldings() {
  const { wb, loading, errors } = useWorkbook();
  const { market } = useMarket();
  const sheetRows = wb?.portfolio ?? [];
  const sheet = sheetRows.length > 0;
  const fx = market?.usdAud;

  const priced = sheet
    ? sheetRows.map((s) => {
        const f = fallbackHoldings.find((h) => h.ticker === s.ticker);
        return { ticker: s.ticker, sleeve: s.sleeve as string, units: s.units, costUsd: f?.costUsd ?? 0, costAud: f?.costAud ?? 0, live: s.live, mv: s.mv, weight: s.weight, div: s.div, changePct: s.changePct as number | null };
      })
    : fallbackHoldings.map((h) => {
        const p = market?.prices[h.ticker];
        const live = p?.price ?? h.live;
        return { ...h, sleeve: h.sleeve as string, live, mv: fx ? h.units * live * fx : h.mv, changePct: p?.changePct ?? null };
      });
  const tot = priced.reduce((a, h) => a + h.mv, 0) || 1;
  const holdings = priced.map((h) => ({ ...h, weight: (h.mv / tot) * 100 }));
  const live = sheet || Object.keys(market?.prices ?? {}).length > 0;
  const sleeves = fallbackSleeves.map((s) => {
    if (!live) return s;
    const actual = Math.round(holdings.filter((h) => h.sleeve === s.name).reduce((a, h) => a + h.weight, 0) * 10) / 10;
    return { ...s, actual };
  });
  return { holdings, sleeves, live, sheet, total: tot, market, loading, error: errors.find((e) => e.includes("Portfolio")) ?? null, fetchedAt: wb?.fetchedAt ?? null };
}
