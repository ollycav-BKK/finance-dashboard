import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, TrendingUp, Landmark, Ship, CalendarDays, BrainCircuit, Zap } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

export const NAV_ITEMS = [
  { title: "Dashboard / Portfolio", url: "/", icon: LayoutDashboard, badge: "Overview" },
  { title: "Projections", url: "/projections", icon: TrendingUp, badge: "DRIP" },
  { title: "Thai Tax", url: "/thai-tax", icon: Landmark, badge: "Paw 161" },
  { title: "Marine", url: "/marine", icon: Ship, badge: "SHIPAUS" },
  { title: "Calendar", url: "/calendar", icon: CalendarDays, badge: "Milestones" },
  { title: "Advisor", url: "/advisor", icon: BrainCircuit, badge: "AI Copilot" },
] as const;

export function AppSidebar() {
  const path = useRouterState({ select: (r) => r.location.pathname });

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <div className="flex items-center gap-2 px-1 py-2">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground shadow-sm">
            <Zap className="h-4 w-4" />
          </div>
          <div className="min-w-0 group-data-[collapsible=icon]:hidden">
            <div className="truncate font-display text-sm font-semibold tracking-tight">Spark Finance OS</div>
            <div className="truncate text-xs text-muted-foreground">O. Cavallaro · ABN 81 315 008 648</div>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Platform Modules
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {NAV_ITEMS.map((item) => {
                const isActive = path === item.url || (item.url !== "/" && path.startsWith(item.url));
                return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild isActive={isActive} tooltip={item.title}>
                      <Link to={item.url} className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </div>
                        {item.badge && (
                          <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground group-data-[collapsible=icon]:hidden">
                            {item.badge}
                          </span>
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
