import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

const tones = {
  primary: "before:bg-primary",
  success: "before:bg-success",
  warning: "before:bg-warning",
  muted: "before:bg-muted-foreground",
};

export function Panel({ title, action, children, className }: { title?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-xl border bg-card p-3.5 sm:p-5", className)}>
      {title && (
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="min-w-0 text-xs font-semibold uppercase tracking-wider text-muted-foreground sm:text-sm">{title}</h2>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

/** Stacked card list shown on phones in place of wide tables. */
export function MobileCard({ title, aside, fields, children }: { title: ReactNode; aside?: ReactNode; fields: [string, ReactNode][]; children?: ReactNode }) {
  return (
    <div className="rounded-lg border bg-background/40 p-3">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2">
        <div className="min-w-0 font-semibold">{title}</div>
        {aside && <div className="shrink-0">{aside}</div>}
      </div>
      {children}
      <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1.5 text-sm">
        {fields.map(([k, v]) => (
          <div key={k} className="min-w-0">
            <dt className="text-xs text-muted-foreground">{k}</dt>
            <dd className="num truncate">{v}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

export function Kpi({ label, value, sub, tone = "primary", icon }: { label: string; value: string; sub: ReactNode; tone?: keyof typeof tones; icon?: ReactNode }) {
  return (
    <div className={cn("relative overflow-hidden rounded-xl border bg-card p-4 sm:p-5 before:absolute before:inset-x-0 before:top-0 before:h-0.5", tones[tone])}>
      <div className="flex items-center justify-between text-xs uppercase tracking-wider text-muted-foreground">
        <span>{label}</span>
        <span className="text-muted-foreground">{icon}</span>
      </div>
      <div className="num mt-3 text-2xl font-semibold">{value}</div>
      <div className="mt-1 text-[13px] leading-relaxed text-muted-foreground sm:text-xs">{sub}</div>
    </div>
  );
}

export function PageHeader({ eyebrow, title, desc }: { eyebrow: string; title: string; desc?: string }) {
  return (
    <header className="mb-6">
      <p className="text-xs font-medium uppercase tracking-[0.2em] text-primary">{eyebrow}</p>
      <h1 className="mt-1 text-2xl font-semibold sm:text-3xl">{title}</h1>
      {desc && <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{desc}</p>}
    </header>
  );
}

export function Tag({ tone, children }: { tone: "primary" | "success" | "warning" | "muted"; children: ReactNode }) {
  const m = {
    primary: "bg-primary/15 text-primary",
    success: "bg-success/15 text-success",
    warning: "bg-warning/15 text-warning",
    muted: "bg-muted text-muted-foreground",
  };
  return <span className={cn("inline-flex rounded-full px-2 py-0.5 text-xs font-medium", m[tone])}>{children}</span>;
}
