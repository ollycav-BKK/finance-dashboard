import { createStart, createCsrfMiddleware, createMiddleware } from "@tanstack/react-start";

import { renderErrorPage } from "./lib/error-page";

const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error != null && typeof error === "object" && "statusCode" in error) {
      throw error;
    }
    console.error(error);
    return new Response(renderErrorPage(), {
      status: 500,
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  }
});

// Start installs this automatically when src/start.ts is absent; defining the
// file opts out, so re-add it explicitly to keep server functions protected
// from cross-site requests.
const csrfMiddleware = createCsrfMiddleware({
  filter: (ctx) => ctx.handlerType === "serverFn",
});

// Passcode gate: every page and API request needs an unlocked session,
// except the unlock page itself. Server functions check individually.
const gateMiddleware = createMiddleware().server(async ({ next, request, handlerType }) => {
  if (handlerType === "serverFn") return next();
  const path = new URL(request.url).pathname;
  if (path === "/unlock") return next();
  const { isUnlocked } = await import("./lib/gate.server");
  if (await isUnlocked()) return next();
  if (path.startsWith("/api/")) return new Response("Locked", { status: 401 });
  return new Response(null, { status: 302, headers: { location: "/unlock" } });
});

export const startInstance = createStart(() => ({
  requestMiddleware: [errorMiddleware, csrfMiddleware, gateMiddleware],
}));
