import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  Lock,
  RefreshCw,
  LayoutDashboard,
  TrendingUp,
  Landmark,
  Ship,
  CalendarDays,
  BrainCircuit,
  Sun,
  Moon,
  ChevronRight,
} from "lucide-react";
import { lockSite } from "@/lib/gate.functions";
import { useWorkbook } from "@/lib/use-sheets";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar, NAV_ITEMS } from "@/components/app-sidebar";
import { CurrencyProvider, useCurrency, type Currency } from "@/lib/currency-context";

const DATA_PAGES = ["/", "/portfolio", "/marine", "/thai-tax", "/projections", "/calendar", "/advisor"];

function BreadcrumbHeader({ pathname }: { pathname: string }) {
  const currentNav = NAV_ITEMS.find((item) => item.url === pathname) || {
    title: pathname === "/" ? "Dashboard / Portfolio" : pathname.replace("/", "").toUpperCase(),
  };

  return (
    <div className="flex items-center gap-1.5 text-xs text-muted-foreground sm:text-sm">
      <Link to="/" className="hover:text-foreground transition-colors">
        Finance OS
      </Link>
      <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/60" />
      <span className="font-semibold text-foreground truncate">{currentNav.title}</span>
    </div>
  );
}

function CurrencySwitcher() {
  const { currency, setCurrency } = useCurrency();
  const currencies: Currency[] = ["AUD", "USD", "THB"];

  return (
    <div className="flex items-center rounded-lg border bg-muted p-0.5 text-xs">
      {currencies.map((c) => (
        <button
          key={c}
          type="button"
          onClick={() => setCurrency(c)}
          className={cn(
            "rounded-md px-2 py-1 font-semibold transition-all",
            currency === c
              ? "bg-card text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          {c === "AUD" ? "A$ AUD" : c === "USD" ? "$ USD" : "฿ THB"}
        </button>
      ))}
    </div>
  );
}

function ThemeToggle() {
  const { theme, toggleTheme } = useCurrency();
  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label="Toggle theme"
      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-md border text-muted-foreground transition-colors hover:text-foreground hover:bg-accent"
      title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
    >
      {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </button>
  );
}

function QuickRefreshButton() {
  const { isSyncing, triggerSync } = useCurrency();

  return (
    <button
      type="button"
      onClick={() => triggerSync()}
      disabled={isSyncing}
      aria-label="Quick refresh and sync"
      className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-md border px-2.5 text-xs text-muted-foreground hover:text-foreground disabled:opacity-70 transition-colors hover:bg-accent"
      title="Synchronize live prices, exchange rates, and ledger records"
    >
      <RefreshCw className={cn("h-4 w-4", isSyncing && "animate-spin text-primary")} />
      <span className="hidden sm:inline">{isSyncing ? "Syncing…" : "Sync"}</span>
    </button>
  );
}

function BottomNav({ pathname }: { pathname: string }) {
  const navs = [
    { to: "/", label: "Dashboard", icon: LayoutDashboard },
    { to: "/projections", label: "Projections", icon: TrendingUp },
    { to: "/thai-tax", label: "Thai Tax", icon: Landmark },
    { to: "/marine", label: "Marine", icon: Ship },
    { to: "/calendar", label: "Calendar", icon: CalendarDays },
    { to: "/advisor", label: "Advisor", icon: BrainCircuit },
  ] as const;

  return (
    <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-6 border-t bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden print:hidden">
      {navs.map(({ to, label, icon: Icon }) => {
        const isActive = pathname === to || (to !== "/" && pathname.startsWith(to));
        return (
          <Link
            key={to}
            to={to}
            className={cn(
              "flex flex-col items-center gap-0.5 py-2 text-[10px]",
              isActive ? "text-primary font-semibold" : "text-muted-foreground"
            )}
          >
            <Icon className="h-4 w-4" />
            <span className="truncate">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

function DataGate({ pathname }: { pathname: string }) {
  const { loading } = useWorkbook();
  if (!loading || !DATA_PAGES.includes(pathname)) return <Outlet />;
  return (
    <div className="space-y-6" aria-busy="true">
      <div className="space-y-2">
        <Skeleton className="h-3 w-32" />
        <Skeleton className="h-8 w-72" />
        <Skeleton className="h-4 w-96 max-w-full" />
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-28 rounded-xl" />
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-5">
        <Skeleton className="h-80 rounded-xl lg:col-span-2" />
        <Skeleton className="h-80 rounded-xl lg:col-span-3" />
      </div>
    </div>
  );
}

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Spark Finance OS — Portfolio & Wealth Management" },
      {
        name: "description",
        content:
          "Consolidated personal finance operating system for portfolio investments, marine charter cash flow, and Thai tax compliance.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Manrope:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap",
      },
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const lock = useServerFn(lockSite);

  if (pathname === "/unlock") {
    return (
      <QueryClientProvider client={queryClient}>
        <CurrencyProvider>
          <Outlet />
        </CurrencyProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <CurrencyProvider>
        <SidebarProvider>
          <div className="flex min-h-screen w-full">
            <AppSidebar />
            <div className="flex min-w-0 flex-1 flex-col">
              <header className="sticky top-0 z-10 flex h-14 items-center justify-between gap-2 border-b bg-background/80 px-3 backdrop-blur sm:gap-3 sm:px-4 print:hidden">
                <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                  <SidebarTrigger className="shrink-0" />
                  <BreadcrumbHeader pathname={pathname} />
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <CurrencySwitcher />
                  <QuickRefreshButton />
                  <ThemeToggle />
                  <button
                    onClick={async () => {
                      await lock();
                      window.location.href = "/unlock";
                    }}
                    aria-label="Lock workspace"
                    className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-md border px-2.5 text-xs text-muted-foreground hover:text-foreground transition-colors hover:bg-accent"
                    title="Lock workspace"
                  >
                    <Lock className="h-4 w-4" />
                    <span className="hidden sm:inline">Lock</span>
                  </button>
                </div>
              </header>

              <main className="mx-auto w-full max-w-7xl flex-1 p-3 pb-24 sm:p-6 md:pb-6 lg:p-8">
                <DataGate pathname={pathname} />
              </main>

              <BottomNav pathname={pathname} />
            </div>
          </div>
        </SidebarProvider>
      </CurrencyProvider>
    </QueryClientProvider>
  );
}
