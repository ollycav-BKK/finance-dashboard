import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Kpi, PageHeader, Panel } from "@/components/kpi";
import { Slider } from "@/components/ui/slider";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PORTFOLIO_VALUE } from "@/lib/finance-data";
import { useCurrency } from "@/lib/currency-context";

export const Route = createFileRoute("/projections")({
  head: () => ({
    meta: [
      { title: "DRP & Compounding Growth Simulator — Spark Finance OS" },
      {
        name: "description",
        content: "Model compound dividend reinvestment, monthly additions, and passive income trajectories.",
      },
      { property: "og:title", content: "DRP & Compounding Growth Simulator" },
      { property: "og:description", content: "Project portfolio value and passive income with dividend reinvestment." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Projections,
});

function Projections() {
  const { formatCurrency } = useCurrency();
  const [yieldPct, setYield] = useState(17.5);
  const [contrib, setContrib] = useState(500);
  const [years, setYears] = useState(5);
  const [divGrowth, setDivGrowth] = useState(3.0);
  const [drip, setDrip] = useState(true);

  const { data, tableRows } = useMemo(() => {
    let v = PORTFOLIO_VALUE;
    let c = PORTFOLIO_VALUE;
    let currentYield = yieldPct / 100;
    const out = [{ year: "Now", value: Math.round(v), contributed: Math.round(c) }];
    const rows = [];

    for (let y = 1; y <= years; y++) {
      const startBal = v;
      const annualContrib = contrib * 12;
      let annualDivs = 0;

      for (let m = 1; m <= 12; m++) {
        const monthlyDiv = v * (currentYield / 12);
        annualDivs += monthlyDiv;
        if (drip) {
          v += monthlyDiv;
        }
        v += contrib;
      }

      c += annualContrib;
      currentYield *= 1 + divGrowth / 100;

      out.push({ year: `Y${y}`, value: Math.round(v), contributed: Math.round(c) });
      rows.push({
        year: `Year ${y}`,
        start: startBal,
        contrib: annualContrib,
        divs: annualDivs,
        end: v,
        passiveMonthly: (v * currentYield) / 12,
      });
    }

    return { data: out, tableRows: rows };
  }, [yieldPct, contrib, years, divGrowth, drip]);

  const last = data[data.length - 1]!;
  const end = last.value;
  const annual = end * (yieldPct / 100);

  const Ctl = ({ label, value, children }: { label: string; value: string; children: React.ReactNode }) => (
    <div>
      <div className="mb-3 flex justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className="num font-semibold text-primary">{value}</span>
      </div>
      {children}
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 06 · Growth Simulator"
        title="DRP & Compounding Growth Projections"
        desc={`Starting from ${formatCurrency(PORTFOLIO_VALUE)} with configurable dividend reinvestment and monthly additions.`}
      />

      <Panel title="Scenario Parameters & Model Controls">
        <div className="grid gap-8 md:grid-cols-4">
          <Ctl label="Net Dividend Yield" value={`${yieldPct.toFixed(1)}%`}>
            <Slider min={8} max={25} step={0.5} value={[yieldPct]} onValueChange={(v) => setYield(v[0] ?? 17.5)} />
          </Ctl>
          <Ctl label="Monthly Addition" value={`${formatCurrency(contrib)} / mo`}>
            <Slider min={0} max={3000} step={50} value={[contrib]} onValueChange={(v) => setContrib(v[0] ?? 500)} />
          </Ctl>
          <Ctl label="Time Horizon" value={`${years} yr${years > 1 ? "s" : ""}`}>
            <Slider min={1} max={15} step={1} value={[years]} onValueChange={(v) => setYears(v[0] ?? 5)} />
          </Ctl>
          <Ctl label="Dividend Growth" value={`${divGrowth.toFixed(1)}% / yr`}>
            <Slider min={0} max={8} step={0.5} value={[divGrowth]} onValueChange={(v) => setDivGrowth(v[0] ?? 3.0)} />
          </Ctl>
        </div>

        <div className="mt-6 flex items-center justify-between border-t pt-4">
          <div>
            <div className="text-sm font-semibold">Dividend Reinvestment Plan (DRIP)</div>
            <div className="text-xs text-muted-foreground">Compound distributions automatically into portfolio balance</div>
          </div>
          <button
            type="button"
            onClick={() => setDrip(!drip)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              drip ? "bg-primary text-primary-foreground border-primary" : "bg-muted text-muted-foreground border-border"
            }`}
          >
            {drip ? "DRIP Enabled" : "Cash Payout"}
          </button>
        </div>
      </Panel>

      <div className="grid gap-4 sm:grid-cols-3">
        <Kpi
          label={`Projected Value · ${years} Years`}
          value={formatCurrency(end)}
          sub={`${(end / PORTFOLIO_VALUE).toFixed(2)}× starting capital`}
        />
        <Kpi
          tone="success"
          label="Projected Passive Income"
          value={`${formatCurrency(annual / 12)} / mo`}
          sub={`${formatCurrency(annual)} / year`}
        />
        <Kpi
          tone="warning"
          label="Contributed Capital"
          value={formatCurrency(last.contributed)}
          sub={`Compound Gain ${formatCurrency(end - last.contributed)}`}
        />
      </div>

      <Panel title="Compound Trajectory Chart">
        <div className="h-80">
          <ResponsiveContainer>
            <AreaChart data={data}>
              <defs>
                <linearGradient id="gv" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="var(--border)" vertical={false} />
              <XAxis dataKey="year" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis
                stroke="var(--muted-foreground)"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `${Math.round(v / 1000)}k`}
              />
              <Tooltip
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                  color: "var(--popover-foreground)",
                }}
                formatter={(v: number) => formatCurrency(v)}
              />
              <Area
                type="monotone"
                dataKey="contributed"
                name="Contributed Capital"
                stroke="var(--muted-foreground)"
                fill="transparent"
                strokeDasharray="4 4"
              />
              <Area
                type="monotone"
                dataKey="value"
                name="Total Portfolio Value"
                stroke="var(--primary)"
                strokeWidth={2}
                fill="url(#gv)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <Panel title="Year-by-Year Progression Table">
        <div className="table-container">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Horizon</TableHead>
                <TableHead className="text-right">Starting Capital</TableHead>
                <TableHead className="text-right">Additions</TableHead>
                <TableHead className="text-right">Dividends</TableHead>
                <TableHead className="text-right">Ending Balance</TableHead>
                <TableHead className="text-right">Monthly Passive Cash Flow</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tableRows.map((r) => (
                <TableRow key={r.year}>
                  <TableCell className="font-semibold">{r.year}</TableCell>
                  <TableCell className="num text-right">{formatCurrency(r.start)}</TableCell>
                  <TableCell className="num text-right text-muted-foreground">+{formatCurrency(r.contrib)}</TableCell>
                  <TableCell className="num text-right text-success font-medium">+{formatCurrency(r.divs)}</TableCell>
                  <TableCell className="num text-right font-bold text-primary">{formatCurrency(r.end)}</TableCell>
                  <TableCell className="num text-right font-semibold">{formatCurrency(r.passiveMonthly)} / mo</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Panel>
    </div>
  );
}
