import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { ShieldCheck, AlertTriangle, Calculator, FileText } from "lucide-react";
import { Kpi, PageHeader, MobileCard, Panel, Tag } from "@/components/kpi";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { useWorkbook } from "@/lib/use-sheets";
import { useCurrency } from "@/lib/currency-context";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/thai-tax")({
  head: () => ({
    meta: [
      { title: "Thai Tax Engine & Deduction Calculator — Spark Finance OS" },
      {
        name: "description",
        content: "Foreign income remittance rules under Orders Paw 161/2566 & 162/2566, tax brackets, and deduction simulator.",
      },
      { property: "og:title", content: "Thai Tax Engine & Deduction Calculator" },
      { property: "og:description", content: "Check assessable overseas remittances, tax brackets and allowable deductions in Thailand." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ThaiTax,
});

const TAX_BRACKETS = [
  { min: 0, max: 150000, rate: 0.0, label: "0 – 150,000", maxTax: 0 },
  { min: 150001, max: 300000, rate: 0.05, label: "150,001 – 300,000", maxTax: 7500 },
  { min: 300001, max: 500000, rate: 0.1, label: "300,001 – 500,000", maxTax: 20000 },
  { min: 500001, max: 750000, rate: 0.15, label: "500,001 – 750,000", maxTax: 37500 },
  { min: 750001, max: 1000000, rate: 0.2, label: "750,001 – 1,000,000", maxTax: 50000 },
  { min: 1000001, max: 2000000, rate: 0.25, label: "1,000,001 – 2,000,000", maxTax: 250000 },
  { min: 2000001, max: 5000000, rate: 0.3, label: "2,000,001 – 5,000,000", maxTax: 900000 },
  { min: 5000001, max: Infinity, rate: 0.35, label: "> 5,000,000", maxTax: Infinity },
];

function verdict(vintage: string, year: string) {
  if (vintage === "Pre-2024") {
    return {
      ok: true,
      title: "EXEMPT under Order Paw 162/2566",
      body: "Income and savings accumulated before 1 January 2024 are grandfathered and completely exempt from Thai PIT upon remittance.",
    };
  }
  if (Number(year) < Number(vintage)) {
    return {
      ok: true,
      title: "Invalid combination",
      body: "Remittance year cannot precede the year the income was generated.",
    };
  }
  return {
    ok: false,
    title: "ASSESSABLE under Order Paw 161/2566 (Report on P.N.D.90)",
    body: `Foreign income generated post-2024 remitted into Thailand while resident (>180 days) is assessable in tax year ${year}. Consider available Double Tax Agreement (DTA) foreign tax credits.`,
  };
}

function ThaiTax() {
  const remits = useWorkbook().wb?.remittances ?? [];
  const { formatCurrency } = useCurrency();
  const [vintage, setVintage] = useState("2026");
  const [year, setYear] = useState("2026");
  const v = verdict(vintage, year);

  // Deduction Calculator States
  const [grossIncomeThb, setGrossIncomeThb] = useState(1560000);
  const [hasSpouse, setHasSpouse] = useState(false);
  const [childCount, setChildCount] = useState(0);
  const [sso, setSso] = useState(9000);
  const [insurance, setInsurance] = useState(50000);
  const [rmfSsf, setRmfSsf] = useState(100000);
  const [mortgage, setMortgage] = useState(45000);
  const [donations, setDonations] = useState(10000);

  // Tax Calculations
  const calculations = useMemo(() => {
    const standardDeduction = Math.min(grossIncomeThb * 0.5, 100000);
    const personalAllowance = 60000;
    const spouseAllowance = hasSpouse ? 60000 : 0;
    const childAllowance = childCount * 30000;
    const ssoActual = Math.min(sso, 9000);
    const insuranceActual = Math.min(insurance, 100000);
    const rmfActual = Math.min(rmfSsf, 500000);
    const mortgageActual = Math.min(mortgage, 100000);

    const totalPreDonationDeductions =
      standardDeduction +
      personalAllowance +
      spouseAllowance +
      childAllowance +
      ssoActual +
      insuranceActual +
      rmfActual +
      mortgageActual;

    const netBeforeDonations = Math.max(0, grossIncomeThb - totalPreDonationDeductions);
    const donationMax = netBeforeDonations * 0.1;
    const donationActual = Math.min(donations, donationMax);
    const totalDeductions = totalPreDonationDeductions + donationActual;

    const netTaxableIncome = Math.max(0, grossIncomeThb - totalDeductions);

    let remaining = netTaxableIncome;
    let totalTax = 0;
    const bracketDetails = TAX_BRACKETS.map((b) => {
      if (remaining <= 0) {
        return { ...b, taxable: 0, tax: 0, active: false };
      }
      const span = b.max - b.min + (b.min === 0 ? 0 : 1);
      const taxable = Math.min(remaining, span);
      const tax = taxable * b.rate;
      totalTax += tax;
      remaining -= taxable;
      return { ...b, taxable, tax, active: taxable > 0 };
    });

    const effectiveRate = grossIncomeThb > 0 ? (totalTax / grossIncomeThb) * 100 : 0;
    const taxAudEquivalent = totalTax / 23.5;

    return {
      standardDeduction,
      personalAllowance,
      totalDeductions,
      netTaxableIncome,
      totalTax,
      effectiveRate,
      taxAudEquivalent,
      bracketDetails,
    };
  }, [grossIncomeThb, hasSpouse, childCount, sso, insurance, rmfSsf, mortgage, donations]);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 05 · Revenue Department Compliance"
        title="Thai Tax Engine & Deduction Calculator"
        desc="Orders Paw 161/2566 & 162/2566 — foreign income remittance assessment, deduction optimization, and progressive tax brackets."
      />

      <div className="grid gap-4 sm:grid-cols-4">
        <Kpi label="Residency Status" value="Bangkok Resident" sub=">180 days / calendar year" />
        <Kpi tone="muted" label="Thai Tax ID (TIN)" value="0991003515691" sub="Bangkok Area 3 PIT" />
        <Kpi tone="warning" label="Annual Filing Window" value="Jan – Mar" sub="P.N.D.90 / 91 returns" />
        <Kpi
          tone="success"
          label="Est. Tax Liability"
          value={`฿${Math.round(calculations.totalTax).toLocaleString("en-AU")}`}
          sub={`Effective Rate: ${calculations.effectiveRate.toFixed(1)}% (${formatCurrency(calculations.taxAudEquivalent)})`}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Panel title="Remittance Taxability Engine" className="lg:col-span-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Fund Vintage</Label>
              <Select value={vintage} onValueChange={setVintage}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pre-2024">Pre-2024 capital</SelectItem>
                  {["2024", "2025", "2026"].map((y) => (
                    <SelectItem key={y} value={y}>
                      {y} income
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Remittance Year</Label>
              <Select value={year} onValueChange={setYear}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {["2024", "2025", "2026", "2027"].map((y) => (
                    <SelectItem key={y} value={y}>
                      {y}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div
            className={cn(
              "mt-5 rounded-lg border p-4",
              v.ok ? "border-success/40 bg-success/10" : "border-warning/40 bg-warning/10"
            )}
          >
            <div className={cn("flex items-start gap-2 font-semibold", v.ok ? "text-success" : "text-warning")}>
              {v.ok ? <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0" /> : <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />}
              {v.title}
            </div>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{v.body}</p>
          </div>
        </Panel>

        <Panel title="Thai Progressive PIT Brackets (2026)" className="lg:col-span-3">
          <div className="table-container">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Taxable Net Income (THB)</TableHead>
                  <TableHead className="text-right">Marginal Rate</TableHead>
                  <TableHead className="text-right">Tax in Bracket</TableHead>
                  <TableHead className="text-right">Max Bracket Tax</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {calculations.bracketDetails.map((b) => (
                  <TableRow key={b.label} className={cn(b.active && "bg-accent/40 font-medium")}>
                    <TableCell>{b.label}</TableCell>
                    <TableCell className="num text-right font-semibold">{(b.rate * 100).toFixed(0)}%</TableCell>
                    <TableCell className="num text-right text-primary">
                      {b.tax > 0 ? `฿${Math.round(b.tax).toLocaleString("en-AU")}` : "—"}
                    </TableCell>
                    <TableCell className="num text-right text-muted-foreground">
                      {b.maxTax === Infinity ? "No cap" : `฿${b.maxTax.toLocaleString("en-AU")}`}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Panel>
      </div>

      {/* Deduction Simulator Panel */}
      <Panel title="Interactive Deduction & Tax Relief Simulator">
        <div className="grid gap-6 md:grid-cols-3">
          <div className="space-y-4">
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Total Assessable Remittance (THB)</Label>
              <Input
                type="number"
                value={grossIncomeThb}
                onChange={(e) => setGrossIncomeThb(Number(e.target.value) || 0)}
                step="50000"
                className="mt-1 num"
              />
              <p className="mt-1 text-xs text-muted-foreground">Equivalent to {formatCurrency(grossIncomeThb / 23.5)}</p>
            </div>

            <div>
              <Label className="text-xs uppercase text-muted-foreground">Standard 50% Expense Deduction</Label>
              <Input
                value={`฿${Math.round(calculations.standardDeduction).toLocaleString("en-AU")} (Max 100k THB)`}
                readOnly
                className="mt-1 bg-muted num"
              />
            </div>

            <div>
              <Label className="text-xs uppercase text-muted-foreground">Personal Taxpayer Allowance</Label>
              <Input value="฿60,000 (Standard Allowance)" readOnly className="mt-1 bg-muted num" />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Social Security (SSO Contribution)</Label>
              <Input
                type="number"
                value={sso}
                onChange={(e) => setSso(Math.min(9000, Number(e.target.value) || 0))}
                max={9000}
                className="mt-1 num"
              />
              <p className="mt-1 text-xs text-muted-foreground">Capped at 9,000 THB/year</p>
            </div>

            <div>
              <Label className="text-xs uppercase text-muted-foreground">Life & Health Insurance</Label>
              <Input
                type="number"
                value={insurance}
                onChange={(e) => setInsurance(Math.min(100000, Number(e.target.value) || 0))}
                max={100000}
                step={5000}
                className="mt-1 num"
              />
              <p className="mt-1 text-xs text-muted-foreground">Up to 100,000 THB</p>
            </div>

            <div>
              <Label className="text-xs uppercase text-muted-foreground">RMF / SSF / Provident Fund</Label>
              <Input
                type="number"
                value={rmfSsf}
                onChange={(e) => setRmfSsf(Math.min(500000, Number(e.target.value) || 0))}
                max={500000}
                step={10000}
                className="mt-1 num"
              />
              <p className="mt-1 text-xs text-muted-foreground">Retirement investments up to 500,000 THB</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Mortgage Interest Deduction</Label>
              <Input
                type="number"
                value={mortgage}
                onChange={(e) => setMortgage(Math.min(100000, Number(e.target.value) || 0))}
                max={100000}
                step={5000}
                className="mt-1 num"
              />
              <p className="mt-1 text-xs text-muted-foreground">Residential interest up to 100,000 THB</p>
            </div>

            <div className="rounded-xl border bg-muted/60 p-4 space-y-2">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Total Allowable Deductions:</span>
                <span className="font-semibold text-foreground num">
                  ฿{Math.round(calculations.totalDeductions).toLocaleString("en-AU")}
                </span>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Net Taxable Base:</span>
                <span className="font-semibold text-foreground num">
                  ฿{Math.round(calculations.netTaxableIncome).toLocaleString("en-AU")}
                </span>
              </div>
              <div className="border-t pt-2 flex justify-between items-center">
                <span className="font-semibold text-sm">Net Tax Payable:</span>
                <span className="text-xl font-bold text-primary num">
                  ฿{Math.round(calculations.totalTax).toLocaleString("en-AU")}
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground text-right">
                Effective Tax Rate: {calculations.effectiveRate.toFixed(2)}%
              </p>
            </div>
          </div>
        </div>
      </Panel>

      {/* Remittance History */}
      <Panel title={`Wise Remittance History (${remits.length} Records)`}>
        <div className="space-y-2 md:hidden">
          {remits.map((r, i) => {
            const vin = /pre/i.test(r.vintage) ? "Pre-2024" : r.vintage;
            const exempt = /exempt/i.test(r.status) || verdict(vin, r.filingYear || r.date.slice(0, 4)).ok;
            return (
              <MobileCard
                key={r.date + i}
                title={<span className="num">{r.date}</span>}
                aside={<Tag tone={exempt ? "success" : "warning"}>{exempt ? "Exempt" : "Assessable"}</Tag>}
                fields={[
                  ["THB received", <span className="font-semibold">฿{r.thb.toLocaleString("en-AU")}</span>],
                  ["Vintage", vin],
                  ["Source", `${r.sourceAmount} @ ${r.rate}`],
                  ["Filing Year", r.filingYear],
                ]}
              >
                <p className="mt-1 text-sm">{r.nature.replace(/_/g, " ")}</p>
              </MobileCard>
            );
          })}
        </div>

        <div className="hidden overflow-x-auto md:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Nature / Source</TableHead>
                <TableHead>Vintage</TableHead>
                <TableHead className="text-right">Sent Amount</TableHead>
                <TableHead className="text-right">THB Received</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {remits.map((r, i) => {
                const vin = /pre/i.test(r.vintage) ? "Pre-2024" : r.vintage;
                const rv = verdict(vin, r.filingYear || r.date.slice(0, 4));
                const exempt = /exempt/i.test(r.status) || rv.ok;
                return (
                  <TableRow key={r.date + i}>
                    <TableCell className="num whitespace-nowrap text-muted-foreground">{r.date}</TableCell>
                    <TableCell className="min-w-56">
                      {r.nature.replace(/_/g, " ")}
                      <div className="text-xs text-muted-foreground">{r.source}</div>
                    </TableCell>
                    <TableCell>
                      {vin}
                      <div className="text-xs text-muted-foreground">Filed {r.filingYear}</div>
                    </TableCell>
                    <TableCell className="num text-right">{r.sourceAmount}</TableCell>
                    <TableCell className="num text-right font-semibold">฿{r.thb.toLocaleString("en-AU")}</TableCell>
                    <TableCell>
                      <Tag tone={exempt ? "success" : "warning"}>{exempt ? "Exempt (Paw 162)" : "Assessable (Paw 161)"}</Tag>
                    </TableCell>
                  </TableRow>
                );
              })}
              {remits.length > 0 && (
                <TableRow className="font-semibold">
                  <TableCell colSpan={4}>Total</TableCell>
                  <TableCell className="num text-right">
                    ฿{remits.reduce((a, r) => a + r.thb, 0).toLocaleString("en-AU")}
                  </TableCell>
                  <TableCell />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </Panel>
    </div>
  );
}
