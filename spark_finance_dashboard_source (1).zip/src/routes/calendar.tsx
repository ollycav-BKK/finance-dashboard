import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { PageHeader, Panel, Tag } from "@/components/kpi";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CalendarDays, Plus } from "lucide-react";

export const Route = createFileRoute("/calendar")({
  head: () => ({
    meta: [
      { title: "Compliance & Lodgement Calendar — Spark Finance OS" },
      { name: "description", content: "ATO BAS deadlines, NEOS distribution dates and Thai tax filing windows." },
      { property: "og:title", content: "Compliance & Lodgement Calendar" },
      { property: "og:description", content: "Every upcoming lodgement and distribution date in one timeline." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CalendarPage,
});

const TODAY = new Date("2026-10-09");
const INITIAL_EVENTS = [
  { date: "2026-10-21", title: "NEOS Distribution Declaration", note: "Approximate monthly declaration for BTCI, NEHI, IAUI, SPYI, QQQI", kind: "Dividend" },
  { date: "2026-11-18", title: "BAS Audit Review", note: "Pre-lodgement review of Q1 FY27", kind: "ATO" },
  { date: "2026-11-25", title: "BAS Q1 FY27 Due", note: "Jul – Sep 2026 BAS Box 1A lodgement & payment", kind: "ATO" },
  { date: "2026-12-20", title: "NEOS Year-End Distribution", note: "Final dividend distribution for 2026 calendar year", kind: "Dividend" },
  { date: "2027-01-01", title: "Thai PIT Filing Window Opens", note: "P.N.D.90 / 91 for 2026 foreign remittance assessment", kind: "Thai" },
  { date: "2027-01-05", title: "Marine Charter Q3 FY27 Invoicing", note: "MV COM 4 Quarterly Bareboat Charter A$7,150", kind: "Marine" },
  { date: "2027-02-28", title: "BAS Q2 FY27 Due", note: "Oct – Dec 2026", kind: "ATO" },
  { date: "2027-03-31", title: "Thai PIT Filing Window Closes", note: "Paper deadline (e-filing deadline 8 April 2027)", kind: "Thai" },
  { date: "2027-04-28", title: "BAS Q3 FY27 Due", note: "Jan – Mar 2027", kind: "ATO" },
  { date: "2027-07-28", title: "BAS Q4 FY27 Due", note: "Apr – Jun 2027", kind: "ATO" },
];

const tone = { ATO: "warning", Dividend: "success", Thai: "primary", Marine: "muted" } as const;

function CalendarPage() {
  const [filter, setFilter] = useState("All");
  const [eventList, setEventList] = useState(INITIAL_EVENTS);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDate, setNewDate] = useState("2026-11-01");
  const [newKind, setNewKind] = useState("Dividend");
  const [newNote, setNewNote] = useState("");

  useEffect(() => {
    try {
      const saved = localStorage.getItem("spark_calendar_events");
      if (saved) setEventList(JSON.parse(saved));
    } catch {}
  }, []);

  const handleAddEvent = () => {
    if (!newTitle.trim()) return;
    const updated = [...eventList, { date: newDate, title: newTitle, kind: newKind, note: newNote }];
    updated.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    setEventList(updated);
    try {
      localStorage.setItem("spark_calendar_events", JSON.stringify(updated));
    } catch {}
    setIsDialogOpen(false);
    setNewTitle("");
    setNewNote("");
  };

  const filtered = eventList.filter((e) => filter === "All" || e.kind === filter);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 07 · Compliance, Payouts & Schedules"
        title="Compliance & Lodgement Calendar"
        desc="Chronological schedule for ATO BAS reporting, NEOS distributions, and Thai personal income tax deadlines."
      />

      <Panel
        title="Timeline & Milestones"
        action={
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-[140px] h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Categories</SelectItem>
                <SelectItem value="Dividend">Dividends</SelectItem>
                <SelectItem value="ATO">ATO BAS</SelectItem>
                <SelectItem value="Thai">Thai PIT</SelectItem>
                <SelectItem value="Marine">Marine Charter</SelectItem>
              </SelectContent>
            </Select>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="h-8 text-xs gap-1">
                  <Plus className="h-3.5 w-3.5" /> Add Milestone
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Add Calendar Milestone</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 py-2 text-sm">
                  <div>
                    <label className="text-xs text-muted-foreground">Event Date</label>
                    <Input type="date" value={newDate} onChange={(e) => setNewDate(e.target.value)} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">Milestone Title</label>
                    <Input
                      placeholder="e.g. Dividend Payout"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">Category</label>
                    <Select value={newKind} onValueChange={setNewKind}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Dividend">Dividend</SelectItem>
                        <SelectItem value="ATO">ATO BAS</SelectItem>
                        <SelectItem value="Thai">Thai PIT</SelectItem>
                        <SelectItem value="Marine">Marine Charter</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">Description / Notes</label>
                    <Input
                      placeholder="e.g. Bank sweep date"
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <Button variant="outline" size="sm" onClick={() => setIsDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button size="sm" onClick={handleAddEvent}>
                      Save Event
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        }
      >
        <ol className="relative space-y-2 border-l pl-6 mt-2">
          {filtered.map((e) => {
            const d = new Date(e.date);
            const days = Math.ceil((d.getTime() - TODAY.getTime()) / 864e5);
            return (
              <li key={e.date + e.title} className="relative rounded-lg p-3 hover:bg-accent/40 transition-colors">
                <span className="absolute -left-[31px] top-5 h-2.5 w-2.5 rounded-full bg-primary ring-4 ring-background" />
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
                  <div className="min-w-0">
                    <div className="num text-xs text-muted-foreground">
                      {d.toLocaleDateString("en-AU", { weekday: "short", day: "2-digit", month: "short", year: "numeric" })}
                    </div>
                    <div className="truncate font-semibold text-sm">{e.title}</div>
                    <div className="truncate text-xs text-muted-foreground mt-0.5">{e.note}</div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Tag tone={tone[e.kind as keyof typeof tone] || "muted"}>{e.kind}</Tag>
                    <span className="num text-xs text-muted-foreground">
                      {days > 0 ? `in ${days} days` : days === 0 ? "Today" : `${Math.abs(days)}d ago`}
                    </span>
                  </div>
                </div>
              </li>
            );
          })}
        </ol>
      </Panel>
    </div>
  );
}
