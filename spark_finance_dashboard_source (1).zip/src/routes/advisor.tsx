import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useRef, useState } from "react";
import { BrainCircuit, RotateCcw } from "lucide-react";
import { Conversation, ConversationContent, ConversationEmptyState, ConversationScrollButton } from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import { PromptInput, PromptInputFooter, PromptInputSubmit, PromptInputTextarea } from "@/components/ai-elements/prompt-input";
import { Reasoning, ReasoningContent, ReasoningTrigger } from "@/components/ai-elements/reasoning";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/kpi";

export const Route = createFileRoute("/advisor")({
  head: () => ({
    meta: [
      { title: "Spark Advisor — Spark Finance OS" },
      { name: "description", content: "Ask questions about your holdings, income, invoices and tax scenarios." },
      { property: "og:title", content: "Spark Advisor — AI financial insights" },
      { property: "og:description", content: "Grounded, actionable answers from your own financial ledger." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdvisorPage,
});

const STORAGE_KEY = "spark-advisor-conversation";
const suggestions = [
  "Where should this month's A$1,463 dividend go, and why?",
  "How much GST will I report at 1A for Q1 FY27?",
  "Is remitting my 2026 charter income to Thailand this year taxable?",
  "Which holding is dragging my returns and what should I watch?",
];

function AdvisorPage() {
  const [initial, setInitial] = useState<UIMessage[] | null>(null);
  useEffect(() => {
    try {
      setInitial(JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]") as UIMessage[]);
    } catch {
      setInitial([]);
    }
  }, []);
  if (!initial) return null;
  return <AdvisorChat initial={initial} />;
}

function AdvisorChat({ initial }: { initial: UIMessage[] }) {
  const [text, setText] = useState("");
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const { messages, sendMessage, status, stop, setMessages } = useChat({
    id: "spark-advisor",
    messages: initial,
    transport: new DefaultChatTransport({ api: "/api/advisor" }),
    onError: (e) => setError(e.message || "Something went wrong. Please try again."),
  });
  const busy = status === "submitted" || status === "streaming";

  useEffect(() => {
    if (status === "ready" || status === "error") {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
      inputRef.current?.focus();
    }
  }, [messages, status]);

  const ask = (q: string) => {
    if (!q.trim() || busy) return;
    setError(null);
    sendMessage({ text: q.trim() });
    setText("");
  };

  const last = messages[messages.length - 1];
  const waiting = busy && (last?.role === "user" || !last?.parts.some((p) => p.type === "text" && p.text));

  return (
    <div className="flex h-[calc(100vh-7.5rem)] flex-col">
      <div className="flex items-start justify-between gap-4">
        <PageHeader eyebrow="Spark Advisor" title="Ask your ledger" desc="Answers grounded in your holdings, invoices, income and tax rules." />
        {messages.length > 0 && (
          <Button variant="secondary" size="sm" onClick={() => { stop(); setMessages([]); localStorage.removeItem(STORAGE_KEY); setError(null); }}>
            <RotateCcw /> New conversation
          </Button>
        )}
      </div>

      <Conversation className="min-h-0 flex-1 rounded-xl border bg-card">
        <ConversationContent>
          {messages.length === 0 ? (
            <ConversationEmptyState
              icon={<div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/15 text-primary"><BrainCircuit className="h-6 w-6" /></div>}
              title="What would you like to know?"
              description="Try one of these, or ask your own question."
            >
              <div className="mt-6 grid w-full max-w-2xl gap-2 sm:grid-cols-2">
                {suggestions.map((s) => (
                  <button key={s} onClick={() => ask(s)} className="rounded-lg border bg-background/50 p-3 text-left text-sm transition-colors hover:border-primary/50 hover:bg-accent">
                    {s}
                  </button>
                ))}
              </div>
            </ConversationEmptyState>
          ) : (
            messages.map((m) => (
              <Message key={m.id} from={m.role}>
                <MessageContent>
                  {m.parts.map((p, i) => {
                    if (p.type === "reasoning") {
                      return (
                        <Reasoning key={i} isStreaming={busy && m.id === last?.id && p.state === "streaming"} defaultOpen={false}>
                          <ReasoningTrigger />
                          <ReasoningContent>{p.text}</ReasoningContent>
                        </Reasoning>
                      );
                    }
                    if (p.type === "text") return <MessageResponse key={i}>{p.text}</MessageResponse>;
                    return null;
                  })}
                </MessageContent>
              </Message>
            ))
          )}
          {waiting && <Shimmer className="text-sm">Analysing your ledger…</Shimmer>}
          {error && <p className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}
        </ConversationContent>
        <ConversationScrollButton />
      </Conversation>

      <PromptInput className="mt-3" onSubmit={() => ask(text)}>
        <PromptInputTextarea
          ref={inputRef}
          autoFocus
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="e.g. What's my projected passive income if I add A$1,000/mo?"
        />
        <PromptInputFooter className="justify-end">
          <PromptInputSubmit status={status} onStop={stop} disabled={!busy && !text.trim()} />
        </PromptInputFooter>
      </PromptInput>
    </div>
  );
}
