import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Lock } from "lucide-react";
import { unlockSite } from "@/lib/gate.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/unlock")({
  head: () => ({
    meta: [
      { title: "Locked · Spark Finance OS" },
      { name: "description", content: "This dashboard is private. Enter the passcode to continue." },
      { property: "og:title", content: "Locked · Spark Finance OS" },
      { property: "og:description", content: "This dashboard is private." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: Unlock,
});

function Unlock() {
  const unlock = useServerFn(unlockSite);
  const [error, setError] = useState(false);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError(false);
    const passcode = String(new FormData(e.currentTarget).get("passcode") ?? "");
    try {
      const { ok } = await unlock({ data: { passcode } });
      if (ok) window.location.href = "/";
      else setError(true);
    } catch {
      setError(true);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <form onSubmit={onSubmit} className="w-full max-w-sm space-y-4 rounded-xl border bg-card p-8">
        <div className="flex items-center gap-2 text-foreground">
          <Lock className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-semibold">Spark Finance OS</h1>
        </div>
        <p className="text-sm text-muted-foreground">Private dashboard. Enter your passcode.</p>
        <Input name="passcode" type="password" autoComplete="current-password" autoFocus required aria-label="Passcode" />
        {error && <p className="text-sm text-destructive">Incorrect passcode</p>}
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Checking…" : "Unlock"}
        </Button>
      </form>
    </div>
  );
}
