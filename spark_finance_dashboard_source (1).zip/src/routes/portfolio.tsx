import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MobileCard, PageHeader, Panel, Tag } from "@/components/kpi";
import { Slider } from "@/components/ui/slider";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useHoldings, useWorkbook } from "@/lib/use-sheets";
import { useCurrency } from "@/lib/currency-context";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "NEOS Portfolio & Drift Engine — Spark Finance OS" },
      { name: "description", content: "1,868 NEOS units, sleeve drift monitoring and dividend reinvestment routing." },
      { property: "og:title", content: "NEOS Portfolio & Drift Engine" },
      { property: "og:description", content: "Holdings, sleeve drift and dividend reinvestment routing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Portfolio,
});

const bar = { primary: "bg-primary", warning: "bg-warning", success: "bg-success" };

function Portfolio() {
  const { holdings, sleeves, live, market, sheet, fetchedAt } = useHoldings();
  const { formatCurrency } = useCurrency();
  const { wb } = useWorkbook();
  const dists = wb?.distributions ?? [];
  const parcels = wb?.parcels ?? [];
  const [cash, setCash] = useState(1463);
  const spyi = Math.round(cash * (750 / 1463));
  const qqqi = cash - spyi;
  const totals = holdings.reduce(
    (a, h) => ({ mv: a.mv + h.mv, div: a.div + h.div, units: a.units + h.units }),
    { mv: 0, div: 0, units: 0 }
  );

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 02 · Asset Allocation"
        title="NEOS Portfolio & Drift Engine"
        desc={`${totals.units.toLocaleString()} verified units across high-yield NEOS option-income ETFs.`}
      />

      <Panel
        title={
          sheet
            ? `Holdings · live from Google Sheets${
                fetchedAt ? " · synced " + new Date(fetchedAt).toLocaleTimeString("en-AU", { timeStyle: "short" }) : ""
              }`
            : live && market
            ? `Holdings · live market rates · USD/AUD ${market.usdAud.toFixed(4)}${market.fxLive ? " (live)" : " (fallback)"}`
            : "Holdings · consolidated positions"
        }
      >
        <div className="space-y-2 md:hidden">
          {holdings.map((h) => (
            <MobileCard
              key={h.ticker}
              title={
                <>
                  {h.ticker} <span className="text-xs font-normal text-muted-foreground">{h.sleeve}</span>
                </>
              }
              aside={
                <div className="text-right">
                  <div className={cn("num font-semibold", h.live >= h.costUsd ? "text-success" : "text-warning")}>
                    ${h.live.toFixed(2)}
                  </div>
                  {h.changePct != null && (
                    <div className="num text-xs text-muted-foreground">
                      {h.changePct >= 0 ? "+" : ""}
                      {h.changePct.toFixed(2)}%
                    </div>
                  )}
                </div>
              }
              fields={[
                ["Market value", <span className="font-semibold">{formatCurrency(h.mv, 2)}</span>],
                ["Weight", `${h.weight.toFixed(2)}%`],
                ["Units", h.units],
                ["Est div / mo", <span className="text-success">{formatCurrency(h.div, 2)}</span>],
              ]}
            >
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-primary" style={{ width: `${Math.min(100, h.weight)}%` }} />
              </div>
            </MobileCard>
          ))}
          <div className="flex justify-between rounded-lg border p-3 font-semibold">
            <span>Total · {totals.units} units</span>
            <span className="num">{formatCurrency(totals.mv, 2)}</span>
          </div>
        </div>

        <div className="hidden overflow-x-auto md:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ticker</TableHead>
                <TableHead>Sleeve</TableHead>
                <TableHead className="text-right">Units</TableHead>
                <TableHead className="text-right">Avg Cost USD</TableHead>
                <TableHead className="text-right">Avg Cost AUD</TableHead>
                <TableHead className="text-right">Live USD</TableHead>
                <TableHead className="text-right">Market Value</TableHead>
                <TableHead className="text-right">Weight</TableHead>
                <TableHead className="text-right">Est Div / mo</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {holdings.map((h) => (
                <TableRow key={h.ticker}>
                  <TableCell className="font-semibold">
                    {h.ticker}
                  </TableCell>
                  <TableCell>
                    <Tag tone="muted">{h.sleeve}</Tag>
                  </TableCell>
                  <TableCell className="num text-right">{h.units.toLocaleString()}</TableCell>
                  <TableCell className="num text-right">${h.costUsd.toFixed(2)}</TableCell>
                  <TableCell className="num text-right">{formatCurrency(h.costAud, 2)}</TableCell>
                  <TableCell className="num text-right font-medium">${h.live.toFixed(2)}</TableCell>
                  <TableCell className="num text-right font-semibold">{formatCurrency(h.mv, 2)}</TableCell>
                  <TableCell className="num text-right">{h.weight.toFixed(1)}%</TableCell>
                  <TableCell className="num text-right text-success font-medium">{formatCurrency(h.div, 2)}</TableCell>
                </TableRow>
              ))}
              <TableRow className="font-semibold border-t">
                <TableCell colSpan={2}>Total Portfolio</TableCell>
                <TableCell className="num text-right">{totals.units.toLocaleString()}</TableCell>
                <TableCell colSpan={3} />
                <TableCell className="num text-right font-bold text-primary">{formatCurrency(totals.mv, 2)}</TableCell>
                <TableCell className="num text-right">100.0%</TableCell>
                <TableCell className="num text-right text-success font-bold">{formatCurrency(totals.div, 2)}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </Panel>

      <Panel title="Sleeve Drift Engine & Reinvestment Routing">
        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            {sleeves.map((s) => (
              <div key={s.name} className="rounded-xl border p-4 bg-muted/40">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold text-sm">{s.name} Sleeve</span>
                  <Tag tone={s.tone as "primary" | "success" | "warning"}>{s.status.split(" — ")[0]}</Tag>
                </div>
                <div className="text-2xl font-bold num">{s.actual}%</div>
                <div className="text-xs text-muted-foreground mt-1">Target range: {s.min}% – {s.max}%</div>
                <div className="mt-3 text-xs leading-relaxed text-muted-foreground">{s.status}</div>
              </div>
            ))}
          </div>

          <div className="rounded-xl border bg-card p-5 mt-4">
            <div className="flex justify-between items-center mb-3">
              <span className="text-sm font-semibold">Simulate Monthly Dividend Routing</span>
              <span className="text-sm font-bold text-primary num">{formatCurrency(cash)}</span>
            </div>
            <Slider min={500} max={3000} step={50} value={[cash]} onValueChange={(v) => setCash(v[0] ?? 1463)} />
            <div className="grid grid-cols-2 gap-4 mt-4 pt-3 border-t text-sm">
              <div>
                <span className="text-xs text-muted-foreground">SPYI Allocation (Equity S&P 500)</span>
                <div className="font-bold num text-primary">{formatCurrency(spyi)}</div>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">QQQI Allocation (Equity Nasdaq 100)</span>
                <div className="font-bold num text-primary">{formatCurrency(qqqi)}</div>
              </div>
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
}
