import { createFileRoute } from "@tanstack/react-router";
import { Kpi, PageHeader, MobileCard, Panel, Tag } from "@/components/kpi";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useLedger } from "@/lib/use-sheets";
import { useCurrency } from "@/lib/currency-context";

export const Route = createFileRoute("/marine")({
  head: () => ({
    meta: [
      { title: "Marine Operations — Spark Finance OS" },
      { name: "description", content: "SHIPAUS Pty Ltd charter and equipment hire ledger with GST tracking." },
      { property: "og:title", content: "Marine Operations — SHIPAUS ledger" },
      { property: "og:description", content: "MV COM 4 charter and PAHE / NEWCHE equipment hire invoices." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Marine,
});

function Marine() {
  const { rows, error, loading } = useLedger();
  const { formatCurrency } = useCurrency();
  const income = rows.filter((r) => r.category.endsWith("_Income"));
  const gst = income.reduce((a, i) => a + i.gst, 0) || 4600;
  const total = income.reduce((a, i) => a + i.total, 0) || 50600;
  const revenue = income.reduce((a, i) => a + i.ex, 0) || 46000;

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 03 · SHIPAUS Pty Ltd"
        title="Marine Operations & Asset Ledger"
        desc="Line Boat Charter MV COM 4 (UVI 464237) and Port Adelaide / Newcastle Equipment Hire (PAHE & NEWCHE)."
      />

      <div className="grid gap-4 sm:grid-cols-4">
        <Kpi
          label="Bareboat Revenue"
          value={formatCurrency(26000)}
          sub={`ex-GST · ${formatCurrency(28600)} gross invoiced`}
        />
        <Kpi
          tone="success"
          label="PAHE ROI Guarantee"
          value={formatCurrency(20000)}
          sub={`ex-GST · ${formatCurrency(22000)} gross invoiced`}
        />
        <Kpi
          tone="warning"
          label="GST Liability (Box 1A)"
          value={formatCurrency(gst)}
          sub={`Revenue ${formatCurrency(revenue)} ex-GST · Gross ${formatCurrency(total)}`}
        />
        <Kpi
          tone="primary"
          label="Fleet Utilization"
          value="98.5%"
          sub="Pacific Marine quarterly active charter"
        />
      </div>

      <Panel title={`Master Ledger · Live Audit Tracking (${rows.length} rows)`}>
        {loading && <p className="text-sm text-muted-foreground">Loading ledger…</p>}
        {error && <p className="text-sm text-warning">{error}</p>}

        <div className="space-y-2 md:hidden">
          {rows.map((i) => (
            <MobileCard
              key={i.id}
              title={
                <>
                  {i.link ? (
                    <a href={i.link} target="_blank" rel="noreferrer" className="underline-offset-2 hover:underline">
                      {i.id}
                    </a>
                  ) : (
                    i.id
                  )}{" "}
                  <span className="num text-xs font-normal text-muted-foreground">· {i.date}</span>
                </>
              }
              aside={<Tag tone={i.status === "Paid" ? "success" : "primary"}>{i.status}</Tag>}
              fields={[
                ["Revenue (ex-GST)", formatCurrency(i.ex, 2)],
                ["GST (10%)", formatCurrency(i.gst, 2)],
                ["Gross (inc-GST)", <span className="font-semibold">{formatCurrency(i.total, 2)}</span>],
              ]}
            >
              <p className="mt-1 text-sm">{i.desc}</p>
              <p className="text-xs text-muted-foreground">
                {i.vendor} · {i.category.replace(/_/g, " ")}
              </p>
            </MobileCard>
          ))}
        </div>

        <div className="hidden overflow-x-auto md:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Entity / Vendor</TableHead>
                <TableHead className="text-right">Revenue (ex-GST)</TableHead>
                <TableHead className="text-right">GST (10%)</TableHead>
                <TableHead className="text-right">Gross Total</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((i) => (
                <TableRow key={i.id}>
                  <TableCell className="num font-semibold">
                    {i.link ? (
                      <a href={i.link} target="_blank" rel="noreferrer" className="hover:underline">
                        {i.id}
                      </a>
                    ) : (
                      i.id
                    )}
                  </TableCell>
                  <TableCell className="num whitespace-nowrap text-muted-foreground">{i.date}</TableCell>
                  <TableCell className="max-w-md truncate">{i.desc}</TableCell>
                  <TableCell className="whitespace-nowrap text-muted-foreground">{i.vendor}</TableCell>
                  <TableCell className="num text-right">{formatCurrency(i.ex, 2)}</TableCell>
                  <TableCell className="num text-right text-warning">{formatCurrency(i.gst, 2)}</TableCell>
                  <TableCell className="num text-right font-semibold">{formatCurrency(i.total, 2)}</TableCell>
                  <TableCell>
                    <Tag tone={i.status === "Paid" ? "success" : "primary"}>{i.status}</Tag>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Panel>
    </div>
  );
}
