import { createFileRoute, Link } from "@tanstack/react-router";
import { PieChart as PieIcon, Wallet, Ship, CalendarClock, Repeat, BookOpen, TrendingUp, Landmark } from "lucide-react";
import { Pie, PieChart, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Kpi, PageHeader, Panel } from "@/components/kpi";
import { Button } from "@/components/ui/button";
import { useHoldings } from "@/lib/use-sheets";
import { useCurrency } from "@/lib/currency-context";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Executive Overview & Portfolio Dashboard — Spark Finance OS" },
      {
        name: "description",
        content: "Portfolio market value, annual income, monthly cash flow, and tax estimates at a glance.",
      },
      { property: "og:title", content: "Executive Overview & Portfolio Dashboard" },
      { property: "og:description", content: "Consolidated portfolio value, cash flow, and tax obligations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Overview,
});

const colors = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)"];

function Overview() {
  const { sleeves, holdings, total, market } = useHoldings();
  const { formatCurrency, currency } = useCurrency();

  const costAud = holdings.reduce((a, h) => a + h.units * h.costAud, 0);
  const gainAud = total - costAud;
  const gainPct = costAud > 0 ? (gainAud / costAud) * 100 : 0;

  // NEOS Dividends (Monthly run-rate in AUD)
  const monthlyDivsAud = holdings.reduce((a, h) => a + h.div, 0);
  const annualDivsAud = monthlyDivsAud * 12;

  // Marine operations (ex-GST)
  const annualMarineAud = 46000;
  const monthlyMarineAud = annualMarineAud / 12;

  // Total Projected Annual Income
  const totalAnnualIncomeAud = annualDivsAud + annualMarineAud;

  // Monthly Cash Flow
  const totalMonthlyCashFlowAud = monthlyDivsAud + monthlyMarineAud;

  // Tax Estimates (ATO BAS GST Box 1A A$4,600 + Thai PIT estimate ~A$4,250)
  const estimatedTaxLiabilityAud = 4600; // Annual GST liability

  const income = [
    { name: "Bareboat MV COM 4", v: 26 },
    { name: "PAHE ROI Guarantee", v: 20 },
    { name: "NEOS Dividends", v: +(annualDivsAud / 1000).toFixed(1) },
  ];
  const totalK = income.reduce((a, i) => a + i.v, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Executive Overview · Wealth Console"
        title="Good morning, Olly"
        desc="Consolidated position across high-yield NEOS income ETFs, SHIPAUS marine charter operations, and Thai tax compliance."
      />

      {/* 4 Required Primary KPI Cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi
          label="Total Portfolio Value"
          value={formatCurrency(total)}
          sub={
            <>
              Cost {formatCurrency(costAud)} ·{" "}
              <span className={gainAud >= 0 ? "text-success font-medium" : "text-warning font-medium"}>
                {gainAud >= 0 ? "+" : "-"}
                {formatCurrency(Math.abs(gainAud))} ({gainPct.toFixed(2)}%)
              </span>
              {market ? (
                <>
                  {" "}
                  · USD/AUD {market.usdAud.toFixed(3)}
                  {market.fxLive ? " (live)" : ""}
                </>
              ) : null}
            </>
          }
          icon={<PieIcon className="h-4 w-4" />}
        />

        <Kpi
          tone="success"
          label="Projected Annual Income"
          value={`${formatCurrency(totalAnnualIncomeAud)} / yr`}
          sub={`NEOS Divs ${formatCurrency(annualDivsAud)} + Marine ${formatCurrency(annualMarineAud)}`}
          icon={<Wallet className="h-4 w-4" />}
        />

        <Kpi
          tone="primary"
          label="Monthly Cash Flow"
          value={`${formatCurrency(totalMonthlyCashFlowAud)} / mo`}
          sub={`Distributions ${formatCurrency(monthlyDivsAud)}/mo · Marine ${formatCurrency(monthlyMarineAud)}/mo`}
          icon={<Ship className="h-4 w-4" />}
        />

        <Kpi
          tone="warning"
          label="Tax Estimates"
          value={formatCurrency(estimatedTaxLiabilityAud)}
          sub="ATO BAS GST (Box 1A) · Next lodgement 25 Nov 2026"
          icon={<CalendarClock className="h-4 w-4" />}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        <Button asChild variant="secondary">
          <Link to="/projections">
            <TrendingUp className="mr-1.5 h-4 w-4" /> Simulate DRIP Compounding
          </Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/marine">
            <BookOpen className="mr-1.5 h-4 w-4" /> Master Marine Ledger
          </Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/thai-tax">
            <Landmark className="mr-1.5 h-4 w-4" /> Thai PIT Deduction Calculator
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Panel title="Asset Allocation & Sleeve Drift" className="lg:col-span-2">
          <div className="h-56">
            <ResponsiveContainer>
              <PieChart>
                <Pie
                  data={sleeves.map((s) => ({ name: s.name, value: s.actual }))}
                  dataKey="value"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={3}
                  stroke="none"
                >
                  {sleeves.map((_, i) => (
                    <Cell key={i} fill={colors[i]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    color: "var(--popover-foreground)",
                  }}
                  formatter={(val: number) => `${val.toFixed(1)}%`}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <ul className="mt-2 space-y-2 text-sm">
            {sleeves.map((s, i) => (
              <li key={s.name} className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: colors[i] }} />
                  <span className="font-medium">{s.name}</span>
                </span>
                <span className="num text-muted-foreground text-xs">
                  <span className="font-semibold text-foreground text-sm">{s.actual}%</span> · target {s.min}–{s.max}%
                </span>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="Annual Income Streams · ex-GST" className="lg:col-span-3">
          <div className="h-72">
            <ResponsiveContainer>
              <BarChart data={income}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  cursor={{ fill: "var(--accent)" }}
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    color: "var(--popover-foreground)",
                  }}
                  formatter={(v: number) => formatCurrency(v * 1000)}
                />
                <Bar dataKey="v" radius={[6, 6, 0, 0]}>
                  {income.map((_, i) => (
                    <Cell
                      key={i}
                      fill={i === 2 ? "var(--success)" : i === 1 ? "var(--warning)" : "var(--primary)"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="num mt-2 text-right text-sm text-muted-foreground">
            Total Annual Turnover ≈ <span className="font-semibold text-foreground">{formatCurrency(totalK * 1000)} ex-GST</span>
          </p>
        </Panel>
      </div>
    </div>
  );
}
